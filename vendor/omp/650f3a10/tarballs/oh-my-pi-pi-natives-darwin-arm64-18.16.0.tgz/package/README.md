# @oh-my-pi/pi-natives-darwin-arm64

Platform native addon package for `@oh-my-pi/pi-natives` on darwin-arm64.

This package is generated during release and installed as an optional dependency of the core package.
