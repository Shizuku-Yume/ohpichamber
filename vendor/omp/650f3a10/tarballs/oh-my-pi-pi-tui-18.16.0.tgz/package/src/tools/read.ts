import type { SummaryResult } from "@oh-my-pi/pi-natives";
import { formatNumberedLine } from "./hashline-format";
import { LINE_RANGE_CHUNK_SOURCE, parseLineRanges } from "./line-ranges";
import * as os from "node:os";
import * as path from "node:path";
import { parseArchivePathCandidates } from "@oh-my-pi/pi-utils/ar";
import { isRecord, sanitizeText } from "@oh-my-pi/pi-utils";
import type { Component } from "../tui";
import { Text } from "../components/text";
import type {
	NativeToolHead,
	RenderResultContextOptions,
	NativeToolView,
	RenderResultOptions,
	ToolActivityContext,
	ToolActivitySummary,
	ToolRenderer,
} from "./renderer";
import { ansi, compact, md } from "../native/describe";
import { base64ImageNode, nativeMediaNode, readMediaPath } from "../native/blobs";
import type { NativeChild, NativeNode } from "../native/node";
import { fileHref, footnoteText, inlineErrorView, resultText } from "./native-view";
import { numberedCode } from "./grouped-file-output";
import { getLanguageFromPath } from "../lang-from-path";
import type { Theme } from "../theme/theme";
import { fileHyperlink, renderCodeCell, renderMarkdownCell, renderStatusLine } from "../render";
import { markFramedBlockComponent } from "../render/output-block";
import { framedToolCard } from "../render/tool-card";
import {
	describeReadUrlCall,
	describeReadUrlResult,
	type ReadUrlToolDetails,
	renderReadUrlCall,
	renderReadUrlResult,
} from "./fetch";
import { formatFullOutputReference, formatStyledTruncationWarning, stripOutputNotice } from "./output-meta";
import { formatBytes, sanitizeDisplayLines, shortenPath, wrapBrackets } from "../render/render-utils";

import type { OutputMeta } from "./output-meta";
import type { TruncationResult } from "./streaming-output";
import { describeProcRead, renderProcRead, type ProcReadDetails } from "./proc-render";
import { describeCfgRead, renderCfgRead, type CfgReadDetails } from "./cfg-render";
import type { CardToolResult } from "./result-card";
import { type InternalUrlSchemeSpec, internalUrlSchemeSpec, splitUrlScheme } from "./url-scheme-host";

/** Read result metadata retains truncation statistics, not a second copy of the body. */
export type ReadTruncationStats = Omit<TruncationResult, "content">;

/** Display metadata for file and URL reads. */
export interface ReadToolDetails {
	kind?: "file" | "url";
	proc?: ProcReadDetails;
	cfg?: CfgReadDetails;
	/** Filesystem hyperlink target resolved by the executing tool. */
	displayTarget?: string;
	truncation?: ReadTruncationStats;
	isDirectory?: boolean;
	resolvedPath?: string;
	/**
	 * Absolute path of the disk file whose image this read returned. A native TSP host that
	 * supports `media` shows the file by path instead of the uploaded image bytes. Unset for
	 * screenshots, URL reads and other images not backed by a file. Display-only.
	 */
	mediaPath?: string;
	suffixResolution?: { from: string; to: string; raw?: boolean };
	/** Raw source output keeps descriptive diagnostics in details, not in the body. */
	raw?: boolean;
	url?: string;
	finalUrl?: string;
	contentType?: string;
	method?: string;
	notes?: string[];
	meta?: OutputMeta;
	/** Full on-disk byte size recorded before applying a file range. */
	fileSize?: number;
	/** Full source line count when the read reached EOF and the count is exact. */
	totalLines?: number;
	/**
	 * Whether the text's rows carry line-number prefixes (`N:` hashline, `N|` line numbers). Set where a
	 * file read is formatted; a raw read sets `false`. Snapcompact reads it to tell a `12:` prefix from content.
	 */
	rowPrefixes?: boolean;
	/** Raw text + start line for user-visible TUI rendering, set when content is text-like.
	 * Mirrors the same lines the model receives but without hashline/line-number prefixes,
	 * so the TUI can render the file content with its own gutter without re-parsing the formatted text. */
	displayContent?: {
		text: string;
		startLine: number;
		lineNumbers?: Array<number | null>;
	};
	summary?: { lines: number; elidedSpans: number; elidedLines: number };
	/** Number of unresolved git conflicts surfaced by this read (TUI uses for inline `⚠ N` badge). */
	conflictCount?: number;
	/**
	 * Paths recovered from a delimited read argument. The TUI renders one call as multiple read rows; snapcompact
	 * keeps such a composite result as text.
	 */
	displayReadTargets?: string[];
	/**
	 * Resolved filesystem link target for each {@link displayReadTargets} entry, aligned by index; `null` when a
	 * delimited part has no linkable fs path. Lets the TUI hyperlink each grouped row the same way a standalone read row is.
	 */
	displayReadTargetLinks?: Array<string | null>;
}

// Parsing also recognizes incomplete counts to explain their errors; path splitting
// only peels complete selectors (not a trailing `+` or `L`).
const RANGE_SELECTOR_CHUNK = `${LINE_RANGE_CHUNK_SOURCE}(?<=[\\d.-])`;
// A tail selector: `-N` reads the last N lines. Keep in sync with TAIL_SELECTOR_RE.
const TAIL_CHUNK_SRC = String.raw`-\d+`;
// A comma list may mix ranges and tails (`1-12,-15`); a lone tail is a one-chunk list.
const LIST_CHUNK_SRC = `(?:${RANGE_SELECTOR_CHUNK}|${TAIL_CHUNK_SRC})`;
const RANGE_LIST_SRC = `${LIST_CHUNK_SRC}(?:,${LIST_CHUNK_SRC})*`;
const FILE_LINE_RANGE_RE = new RegExp(`^(?:${RANGE_LIST_SRC}|raw|conflicts|img)$`, "i");
const FILE_LINE_RANGE_ONLY_RE = new RegExp(`^(?:${RANGE_LIST_SRC})$`, "i");
const FILE_RAW_ONLY_RE = /^raw$/i;
// Permissive selector chunk for internal URLs — accepts well-formed selectors
// plus common malformed shapes (e.g. `:-N-M`) so the read tool peels the entire
// selector chain off before dispatching to a protocol handler.
const INTERNAL_URL_SELECTOR_PART_RE = new RegExp(
	String.raw`^(?:raw|conflicts|img|${RANGE_LIST_SRC}|-\d+(?:[-+]\d+)?)$`,
	"i",
);

/**
 * Fold the list chunks that repeat the selector colon after a comma (`a:1-30,:-30`)
 * into the `list` that follows them, so the pair reads as `a:1-30,-30`. Only
 * colons at or after `minColon` count. Each chunk is tested once.
 */
function foldRepeatedListColons(basePath: string, list: string, minColon: number): { basePath: string; list: string } {
	const chunks = [list];
	while (basePath.endsWith(",")) {
		const colon = basePath.lastIndexOf(":");
		const chunk = basePath.slice(colon + 1, -1);
		if (colon < minColon || !FILE_LINE_RANGE_ONLY_RE.test(chunk)) break;
		chunks.push(chunk);
		basePath = basePath.slice(0, colon);
	}
	return { basePath, list: chunks.reverse().join(",") };
}

/**
 * Split a filesystem path from its trailing read selector. `foldListColons: false`
 * keeps a colon repeated inside a list as part of the path (`a:1-30,:-30` peels
 * only `:-30`), for callers checking whether that shorter split names a real file.
 */
export function splitPathAndSel(
	rawPath: string,
	options?: { foldListColons?: boolean },
): { path: string; sel?: string } {
	const colon = rawPath.lastIndexOf(":");
	if (colon <= 0) return { path: rawPath };

	const candidate = rawPath.slice(colon + 1);
	if (!FILE_LINE_RANGE_RE.test(candidate)) return { path: rawPath };

	let basePath = rawPath.slice(0, colon);
	// Allow a compound trailing selector: `path:1-50:raw`, `path:raw:1-50`, or
	// `path:raw:-60`. The two chunks must be one line list (ranges and tails)
	// plus one `raw`, in either order.
	let list: string | undefined;
	let rawSuffix = "";
	if (FILE_LINE_RANGE_ONLY_RE.test(candidate)) {
		list = candidate;
	} else if (FILE_RAW_ONLY_RE.test(candidate)) {
		const innerColon = basePath.lastIndexOf(":");
		const innerCandidate = basePath.slice(innerColon + 1);
		if (innerColon > 0 && FILE_LINE_RANGE_ONLY_RE.test(innerCandidate)) {
			list = innerCandidate;
			rawSuffix = `:${candidate}`;
			basePath = basePath.slice(0, innerColon);
		}
	}
	if (list === undefined) return { path: basePath, sel: candidate };

	if (options?.foldListColons !== false) ({ basePath, list } = foldRepeatedListColons(basePath, list, 1));
	if (!rawSuffix) {
		const innerColon = basePath.lastIndexOf(":");
		const innerCandidate = basePath.slice(innerColon + 1);
		if (innerColon > 0 && FILE_RAW_ONLY_RE.test(innerCandidate)) {
			return { path: basePath.slice(0, innerColon), sel: `${innerCandidate}:${list}` };
		}
	}
	return { path: basePath, sel: `${list}${rawSuffix}` };
}

/**
 * Variant of {@link splitPathAndSel} for internal URLs (`scheme://...`).
 *
 * The filesystem-path splitter is intentionally conservative: it refuses to
 * peel a trailing `:<chunk>` unless that chunk matches the strict selector
 * grammar. That rule is right for filesystem paths (a file named `a:1-50` is
 * legal) but wrong for internal URLs, where any trailing `:<chunk>` after the
 * scheme is unambiguously a read-tool selector — even if malformed (e.g.
 * `artifact://3:raw:-100-5`).
 *
 * This function iteratively peels selector-shaped chunks (well-formed plus
 * common malformed shapes like `:-N-M`) so the rest of the read tool can pass a
 * clean URL to the protocol handler and surface selector errors via parseSel
 * instead of as misleading "host invalid" errors from the handler.
 *
 * Only schemes whose spec declares `lines` selectors peel; server-defined URIs
 * (`opaque`), selector-free schemes, and unregistered schemes pass through
 * verbatim. `specOf` defaults to the installed scheme host, so nothing peels
 * before a host is installed.
 *
 * Falls back to the input unchanged when nothing matches.
 */
export function splitInternalUrlSel(
	rawPath: string,
	specOf: (scheme: string) => InternalUrlSchemeSpec | undefined = internalUrlSchemeSpec,
): { path: string; sel?: string } {
	const url = splitUrlScheme(rawPath);
	if (!url) return { path: rawPath };
	const spec = specOf(url.scheme);
	if (spec?.selectors !== "lines") return { path: rawPath };
	// With no `/path` after the authority, a trailing `:N` is the port
	// (ssh://host:2222), not a read selector.
	if (spec.portAuthority && !url.rest.includes("/")) return { path: rawPath };

	const schemeEnd = rawPath.length - url.rest.length;
	let path = rawPath;
	const chunks: string[] = [];
	while (true) {
		const colon = path.lastIndexOf(":");
		// Stop before crossing into the scheme separator `://`.
		if (colon < schemeEnd) break;
		const tail = path.slice(colon + 1);
		if (INTERNAL_URL_SELECTOR_PART_RE.test(tail)) {
			chunks.unshift(tail);
			path = path.slice(0, colon);
			continue;
		}
		// `artifact://7:1-30,:-30`: a list chunk ending in a comma joins the list peeled after it.
		if (chunks.length === 0 || !FILE_LINE_RANGE_ONLY_RE.test(chunks[0])) break;
		const folded = foldRepeatedListColons(path, chunks[0], schemeEnd);
		if (folded.basePath === path) break;
		chunks[0] = folded.list;
		path = folded.basePath;
	}
	if (chunks.length === 0) return { path: rawPath };
	return { path, sel: chunks.join(":") };
}

/** A read query after a filesystem path: `?key=` (`?q=…`, `?limit=…&where=…`), not a `\\?\` long-path prefix. */
const READ_QUERY_RE = /(?<!^\\\\)\?\w+=/;

/**
 * Split a filesystem read target from its query (`data.json?q=.items` →
 * `data.json`, `?q=.items`), the display twin of the read tool's JSON, SQLite
 * and image-question parsers. URLs own their query string and stay whole, as
 * does a `?` inside a file name.
 */
export function splitReadQuery(readPath: string): { path: string; query?: string } {
	const at = splitUrlScheme(readPath) ? -1 : readPath.search(READ_QUERY_RE);
	return at > 0 ? { path: readPath.slice(0, at), query: readPath.slice(at) } : { path: readPath };
}

/** Recognize HTTP URLs and www-prefixed external read targets. */
export function isReadableUrlPath(value: string): boolean {
	return /^https?:\/\/?/i.test(value) || /^www\./i.test(value);
}

/** Return the first selected line when every range has valid one-based bounds. */
export function readSelectorRangeStart(selector: string): number | undefined {
	try {
		const start = parseLineRanges(selector)?.[0].startLine;
		return start !== undefined && Number.isFinite(start) ? start : undefined;
	} catch {
		return undefined;
	}
}

// =============================================================================
// TUI Renderer
// =============================================================================

export interface ReadRenderArgs {
	path?: unknown;
	file_path?: unknown;
	// Legacy fields from old schema — tolerated for in-flight tool calls during transition
	offset?: number;
	limit?: number;
	raw?: boolean;
}

/** Transcript card for reads of a scheme with its own UI (process table, settings tree). */
interface ReadUrlCard {
	/** Activity label, e.g. `Process · web`. */
	readonly label: string;
	/** Activity detail when the URL names no target. */
	readonly rootDetail: string;
	/** Result details field whose presence identifies this card. */
	readonly detailsKey: "proc" | "cfg";
	/** Pending call card when `result` is undefined, else the finished result card. */
	render(
		url: string,
		target: string,
		result: CardToolResult | undefined,
		details: ReadToolDetails | undefined,
		options: RenderResultOptions,
		uiTheme: Theme,
	): Component;
}

/** Read cards keyed by URL scheme. */
const READ_URL_CARDS: Record<string, ReadUrlCard> = {
	proc: {
		label: "Process",
		rootDetail: "jobs & services",
		detailsKey: "proc",
		render: (_url, target, result, details, options, uiTheme) =>
			renderProcRead(target, result, details?.proc, options, uiTheme),
	},
	cfg: {
		label: "Config",
		rootDetail: "all settings",
		detailsKey: "cfg",
		render: (url, _target, result, details, options, uiTheme) =>
			renderCfgRead(splitInternalUrlSel(url).path, result, details?.cfg, options, uiTheme),
	},
};

/**
 * Card that renders a read of `rawPath` with the text after `scheme://` as its target.
 * Result details identify the card before the URL scheme does.
 */
function readUrlCard(rawPath: string, details?: ReadToolDetails): { card: ReadUrlCard; target: string } | undefined {
	const url = splitUrlScheme(rawPath);
	const target = url?.rest ?? "";
	if (details) {
		for (const scheme in READ_URL_CARDS) {
			const card = READ_URL_CARDS[scheme];
			if (details[card.detailsKey] !== undefined) return { card, target };
		}
	}
	if (!url || !Object.hasOwn(READ_URL_CARDS, url.scheme)) return undefined;
	return { card: READ_URL_CARDS[url.scheme], target };
}

// A scheme-less host followed by a slash can be a web target. Do not force a
// file: link onto it; explicit relative paths (./host/path) remain filesystem paths.
const BARE_WEB_HOST_RE = /^(?:(?:[a-z][a-z0-9-]*|\[[0-9a-f:]+\])(?::\d+)|(?:[a-z0-9-]+\.)+[a-z0-9-]+(?::\d+)?)\//i;

/** Local file a pending read/write input points at, before the tool resolves it:
 * expands `~` and drops archive-member / SQLite-row selectors so the link opens
 * the containing file. */
export function pendingFileLinkPath(inputPath: string): string {
	const expanded = inputPath.replace(/^~(?=$|[\\/])/, os.homedir());
	if (!expanded.includes(":")) return path.resolve(expanded);
	const archive = parseArchivePathCandidates(expanded).find(candidate => candidate.archivePath !== expanded);
	const sqlite = expanded.match(/^(.+\.(?:sqlite3?|db3?))(?=[:?])/i);
	return path.resolve(archive?.archivePath ?? sqlite?.[1] ?? expanded);
}

function splitReadRenderPath(rawPath: string): { path: string; sel?: string } {
	if (splitUrlScheme(rawPath)) {
		const internal = splitInternalUrlSel(rawPath);
		if (internal.sel) return internal;
	}
	return splitPathAndSel(rawPath);
}

function firstReadSelectorLine(sel: string | undefined): number | undefined {
	if (!sel) return undefined;
	const range = sel.split(":").find(chunk => chunk.toLowerCase() !== "raw");
	return range ? readSelectorRangeStart(range) : undefined;
}

/** Absolute fs path the read result actually resolved to, used as the OSC 8 link
 * target when the structured `resolvedPath` isn't set (the common plain-file and
 * image reads only record the path in `meta.source`). URL/internal sources are
 * not fs paths, so only `type: "path"` qualifies. */
export function readSourceFsPath(details: unknown): string | undefined {
	if (!isRecord(details) || !isRecord(details.meta) || !isRecord(details.meta.source)) return undefined;
	const source = details.meta.source;
	return source.type === "path" && typeof source.value === "string" ? source.value : undefined;
}

function readLinkTarget(details: unknown): string | undefined {
	if (!isRecord(details)) return undefined;
	if (typeof details.resolvedPath === "string") return details.resolvedPath;
	if (typeof details.displayTarget === "string") return details.displayTarget;
	return readSourceFsPath(details);
}

function formatReadPathLink(
	rawPath: string,
	options: {
		resolvedPath?: string;
		sourcePath?: string;
		suffixResolution?: { from: string; to: string };
		offset?: number;
		fallbackLabel?: string;
	},
): string {
	const split = splitReadRenderPath(rawPath);
	const basePath = split.path || rawPath;
	const selectorSuffix = split.sel ? `:${split.sel}` : "";
	const plainDisplayPath = sanitizeText(
		options.suffixResolution
			? shortenPath(options.suffixResolution.to)
			: shortenPath(basePath || options.resolvedPath || options.fallbackLabel || rawPath),
	);
	// Calls render before the tool has resolved a filesystem target. Preserve
	// protocol resources as plain text, but resolve direct relative file paths
	// so terminals receive an explicit file: link rather than guessing HTTPS.
	const inputPath =
		basePath && !splitUrlScheme(basePath) && !BARE_WEB_HOST_RE.test(basePath)
			? pendingFileLinkPath(basePath)
			: undefined;
	const target = options.resolvedPath ?? options.sourcePath ?? inputPath;
	const line = firstReadSelectorLine(split.sel) ?? options.offset;
	const linkOptions = line !== undefined ? { line } : undefined;
	const linkedPath = target ? fileHyperlink(target, plainDisplayPath, linkOptions) : plainDisplayPath;
	return `${linkedPath}${selectorSuffix}`;
}

function readRawPath(args: ReadRenderArgs | undefined): string {
	return typeof args?.file_path === "string" ? args.file_path : typeof args?.path === "string" ? args.path : "";
}

/**
 * Whether a read result renders as a Markdown preview rather than numbered source:
 * the read tool tagged it `text/markdown` (`read.renderMarkdown`, or a protocol
 * resource) and the call did not ask for `:raw` source. Shared by the standalone
 * read card and the read group's content previews so both honor the setting.
 */
export function readResultIsMarkdown(details: ReadToolDetails | undefined, args: ReadRenderArgs | undefined): boolean {
	if (details?.contentType !== "text/markdown" || args?.raw === true) return false;
	const sel = splitReadRenderPath(readRawPath(args)).sel;
	return sel?.split(":").some(chunk => chunk.toLowerCase() === "raw") !== true;
}

/**
 * Native read head (§7.3 read): `Read path:13-36` with the path as the
 * target (shortened, plus the selector / legacy offset range), a `file://`
 * link when the fs path is known, and a suffix correction as meta.
 */
function readNativeHead(
	rawPath: string,
	args: ReadRenderArgs | undefined,
	details?: ReadToolDetails,
	linkPath?: string,
): NativeToolHead {
	const split = splitReadRenderPath(rawPath);
	const suffix = details?.suffixResolution;
	let target = suffix ? shortenPath(suffix.to) : shortenPath(split.path || rawPath);
	if (split.sel) target += `:${split.sel}`;
	if (args?.offset !== undefined || args?.limit !== undefined) {
		const startLine = args.offset ?? 1;
		const endLine = args.limit !== undefined ? startLine + args.limit - 1 : "";
		target += `:${startLine}${endLine ? `-${endLine}` : ""}`;
	}
	const meta: string[] = [];
	if (suffix) meta.push(`corrected from ${shortenPath(suffix.from)}`);
	if (details?.summary) {
		const n = details.summary.elidedSpans;
		meta.push(`summary: ${n} elided span${n === 1 ? "" : "s"}`);
	}
	const conflicts = details?.conflictCount ?? 0;
	return {
		title: "Read",
		target: sanitizeText(target) || "…",
		targetKind: "path",
		href: fileHref(linkPath ?? details?.resolvedPath ?? details?.displayTarget ?? readSourceFsPath(details)),
		meta,
		badges:
			conflicts > 0 ? [{ text: `${conflicts} conflict${conflicts === 1 ? "" : "s"}`, tone: "warning" }] : undefined,
	};
}

/**
 * The first line a read shows: the selector's (or legacy `offset`'s) range
 * start, so legacy results without `displayContent` still number from there.
 */
function readRangeStart(rawPath: string, args: ReadRenderArgs | undefined): number {
	const sel = splitReadRenderPath(rawPath).sel;
	return firstReadSelectorLine(sel) ?? args?.offset ?? 1;
}

/**
 * Read content as one numbered, wrapped `code` block (no path header: the head
 * names the file), matching the ANSI preview's hanging wrap. Numbers come from
 * `lineNumbers` (`displayContent`'s per-line numbers, `null` for an elided
 * block, which Tern shows as a `…` gap row where the numbers jump) when they
 * cover every line, else count up from `start`.
 */
export function readContentCode(
	content: string,
	start: number,
	numbers: readonly (number | null)[] | undefined,
	path: string | undefined,
): NativeNode[] {
	const lines = content.split("\n");
	const block = numberedCode(
		lines.map((text, i) => ({ n: numbers && numbers.length === lines.length ? numbers[i]! : start + i, text })),
		{ path, wrap: true },
	);
	return block ? [block] : [];
}

/** An image content block as the read tool emits it (base64 data + mime type). */
interface ReadImageBlock {
	type: "image";
	data: string;
	mimeType: string;
}

function isImageBlock(block: { type: string }): block is ReadImageBlock {
	return (
		block.type === "image" &&
		typeof (block as Partial<ReadImageBlock>).data === "string" &&
		typeof (block as Partial<ReadImageBlock>).mimeType === "string"
	);
}

/** Cached `image` node on its content block, so decoding and hashing happen once per block. */
const kReadImageNode = Symbol("read.imageNode");

interface TaggedReadImageBlock extends ReadImageBlock {
	[kReadImageNode]?: NativeNode;
}

/** Native `image` node for a read image: registered blob, alt = displayed path, source pixel size when parseable. */
function describeReadImage(block: TaggedReadImageBlock, alt: string): NativeNode {
	const cached = block[kReadImageNode];
	if (cached) return cached;
	const described = base64ImageNode(block.data, block.mimeType, { alt: alt || "image", role: "omp.tool.read.image" });
	block[kReadImageNode] = described;
	return described;
}

/** Render file, image, and URL reads in the transcript. */
export const readToolRenderer = {
	activitySummary(args: unknown, _context: ToolActivityContext): ToolActivitySummary {
		const input = args as ReadRenderArgs | undefined;
		const rawPath =
			typeof input?.file_path === "string" ? input.file_path : typeof input?.path === "string" ? input.path : "";
		const routed = readUrlCard(rawPath);
		if (routed) return { label: routed.card.label, detail: routed.target || routed.card.rootDetail };
		return { label: "Read", detail: sanitizeText(shortenPath(rawPath)) };
	},
	renderCall(args: ReadRenderArgs, _options: RenderResultOptions, uiTheme: Theme): Component {
		const rawPath =
			typeof args.file_path === "string" ? args.file_path : typeof args.path === "string" ? args.path : "";
		const routed = readUrlCard(rawPath);
		if (routed) return routed.card.render(rawPath, routed.target, undefined, undefined, _options, uiTheme);
		if (isReadableUrlPath(rawPath)) {
			return renderReadUrlCall({ path: rawPath, raw: args.raw }, _options, uiTheme);
		}

		const offset = args.offset;
		const limit = args.limit;

		let pathDisplay = formatReadPathLink(rawPath, { offset, fallbackLabel: "…" }) || "…";
		if (offset !== undefined || limit !== undefined) {
			const startLine = offset ?? 1;
			const endLine = limit !== undefined ? startLine + limit - 1 : "";
			pathDisplay += `:${startLine}${endLine ? `-${endLine}` : ""}`;
		}

		const text = renderStatusLine({ icon: "pending", title: "Read", description: pathDisplay }, uiTheme);
		return new Text(text, 0, 0);
	},

	renderResult(
		result: { content: Array<{ type: string; text?: string }>; details?: ReadToolDetails; isError?: boolean },
		options: RenderResultContextOptions,
		uiTheme: Theme,
		args?: ReadRenderArgs,
	): Component {
		const linkPath = readLinkTarget(options.renderContext?.rawDetails);
		const urlDetails = result.details as ReadUrlToolDetails | undefined;
		const baseRawPathForKind =
			typeof args?.file_path === "string" ? args.file_path : typeof args?.path === "string" ? args.path : "";
		const routed = readUrlCard(baseRawPathForKind, result.details);
		if (routed)
			return routed.card.render(baseRawPathForKind, routed.target, result, result.details, options, uiTheme);
		if (urlDetails?.kind === "url" || isReadableUrlPath(baseRawPathForKind)) {
			return renderReadUrlResult(
				result as {
					content: Array<{ type: string; text?: string }>;
					details?: ReadUrlToolDetails;
					isError?: boolean;
				},
				options,
				uiTheme,
			);
		}

		if (result.isError) {
			const rawErrorText = result.content?.find(c => c.type === "text")?.text ?? "";
			const errorText = (rawErrorText || "Unknown error").replace(/^Error:\s*/, "");
			const rawPath =
				typeof args?.file_path === "string" ? args.file_path : typeof args?.path === "string" ? args.path : "";
			const filePath =
				formatReadPathLink(rawPath, {
					offset: args?.offset,
					sourcePath: linkPath ?? result.details?.displayTarget ?? readSourceFsPath(result.details),
				}) || sanitizeText(shortenPath(rawPath));
			let title = filePath ? `Read ${filePath}` : "Read";
			if (args?.offset !== undefined || args?.limit !== undefined) {
				const startLine = args.offset ?? 1;
				const endLine = args.limit !== undefined ? startLine + args.limit - 1 : "";
				title += `:${startLine}${endLine ? `-${endLine}` : ""}`;
			}
			const header = renderStatusLine({ icon: "error", title }, uiTheme);
			const errorLines = sanitizeDisplayLines(errorText).map(line => uiTheme.fg("error", line));
			return framedToolCard(uiTheme, () => ({
				header,
				phase: "error",
				sections: [{ content: errorLines }],
			}));
		}
		const details = result.details;
		const rawText = result.content?.find(c => c.type === "text")?.text ?? "";
		// Prefer structured `displayContent` from details when available so the TUI
		// shows clean file content (no model-only hashline anchors) without parsing the formatted text.
		// Fall back to the raw text, but strip the LLM-facing notice so it doesn't
		// echo next to the styled warning line below.
		const contentText = details?.displayContent?.text ?? stripOutputNotice(rawText, details?.meta);
		const imageContent = result.content?.find(c => c.type === "image");
		const rawPath =
			typeof args?.file_path === "string" ? args.file_path : typeof args?.path === "string" ? args.path : "";
		const renderPath = splitReadRenderPath(rawPath);
		const lang = getLanguageFromPath(renderPath.path);

		const warningLines: string[] = [];
		const truncation = details?.meta?.truncation;
		const fallback = details?.truncation;
		if (details?.resolvedPath) {
			warningLines.push(
				uiTheme.fg("dim", wrapBrackets(`Resolved path: ${shortenPath(details.resolvedPath)}`, uiTheme)),
			);
		}
		if (truncation) {
			if (fallback?.firstLineExceedsLimit) {
				let warning = `First line exceeds ${formatBytes(fallback.outputBytes ?? fallback.totalBytes)} limit`;
				if (truncation.artifactId) {
					warning += `. ${formatFullOutputReference(truncation.artifactId)}`;
				}
				warningLines.push(uiTheme.fg("warning", wrapBrackets(warning, uiTheme)));
			} else {
				const warning = formatStyledTruncationWarning(details?.meta, uiTheme);
				if (warning) warningLines.push(warning);
			}
		}

		if (imageContent) {
			const suffix = details?.suffixResolution;
			const displayPath = formatReadPathLink(rawPath, {
				resolvedPath: linkPath ?? details?.resolvedPath,
				sourcePath: details?.displayTarget ?? readSourceFsPath(details),
				suffixResolution: suffix,
				fallbackLabel: "image",
			});
			const correction = suffix ? ` ${uiTheme.fg("dim", `(corrected from ${shortenPath(suffix.from)})`)}` : "";
			const header = renderStatusLine(
				{ icon: suffix ? "warning" : "success", title: "Read", description: `${displayPath}${correction}` },
				uiTheme,
			);
			const detailLines = contentText
				? sanitizeDisplayLines(contentText).map(line => uiTheme.fg("toolOutput", line))
				: [];
			const lines = [...detailLines, ...warningLines];
			return framedToolCard(uiTheme, () => ({
				header,
				phase: "success",
				sections: [
					{
						label: uiTheme.fg("toolTitle", "Details"),
						content: lines.length > 0 ? lines : [uiTheme.fg("dim", "(image)")],
					},
				],
			}));
		}

		const suffix = details?.suffixResolution;
		// resolvedPath is the absolute fs path when a read resolved/corrected the
		// input (suffix match, internal URL, archive/sqlite/notebook); plain file
		// reads only record the absolute path in meta.source, so fall back to that
		// to keep the title clickable.
		const displayPath = formatReadPathLink(rawPath, {
			resolvedPath: linkPath ?? details?.resolvedPath,
			sourcePath: details?.displayTarget ?? readSourceFsPath(details),
			suffixResolution: suffix,
			offset: args?.offset,
		});
		const correction = suffix ? ` ${uiTheme.fg("dim", `(corrected from ${shortenPath(suffix.from)})`)}` : "";
		let title = displayPath ? `Read ${displayPath}${correction}` : "Read";
		if (args?.offset !== undefined || args?.limit !== undefined) {
			const startLine = args.offset ?? 1;
			const endLine = args.limit !== undefined ? startLine + args.limit - 1 : "";
			title += `:${startLine}${endLine ? `-${endLine}` : ""}`;
		}
		if (details?.summary) {
			title += ` (summary: ${details.summary.elidedSpans} elided span${details.summary.elidedSpans === 1 ? "" : "s"})`;
		}
		if (details?.conflictCount && details.conflictCount > 0) {
			const n = details.conflictCount;
			title += ` ${uiTheme.fg("warning", `(⚠ ${n} conflict${n === 1 ? "" : "s"})`)}`;
		}
		const isMarkdown = readResultIsMarkdown(details, args);
		let cachedWidth: number | undefined;
		let cachedExpanded: boolean | undefined;
		let cachedLines: string[] | undefined;
		const dropCache = () => {
			cachedWidth = undefined;
			cachedExpanded = undefined;
			cachedLines = undefined;
		};
		return markFramedBlockComponent({
			render: (width: number) => {
				const expanded = options.expanded;
				if (cachedLines && cachedWidth === width && cachedExpanded === expanded) return cachedLines;
				cachedLines = isMarkdown
					? renderMarkdownCell(
							{
								content: contentText,
								title,
								status: "complete",
								output: warningLines.length > 0 ? warningLines.join("\n") : undefined,
								expanded,
								width,
							},
							uiTheme,
						)
					: renderCodeCell(
							{
								code: contentText,
								language: lang,
								title,
								status: "complete",
								output: warningLines.length > 0 ? warningLines.join("\n") : undefined,
								expanded,
								codeStartLine: details?.displayContent?.startLine,
								codeLineNumbers: details?.displayContent?.lineNumbers,
								width,
							},
							uiTheme,
						);
				cachedWidth = width;
				cachedExpanded = expanded;
				return cachedLines;
			},
			invalidate: dropCache,
			releaseRenderCaches: dropCache,
		});
	},
	describeCall(args: ReadRenderArgs): NativeToolView {
		const rawPath = readRawPath(args);
		const routed = readUrlCard(rawPath);
		if (routed?.card.detailsKey === "proc") return describeProcRead(routed.target, undefined, undefined);
		if (routed) return describeCfgRead(splitInternalUrlSel(rawPath).path, undefined, undefined);
		if (isReadableUrlPath(rawPath)) return describeReadUrlCall({ path: rawPath, raw: args.raw });
		return { tool: readNativeHead(rawPath, args), inline: true };
	},

	/**
	 * Inline (§7.3 read): the head names the file and range; the content
	 * (numbered from the range start, no path header) is the disclosed body.
	 * An error shows its message in the head, never behind the disclosure.
	 */
	describeResult(
		result: { content: Array<{ type: string; text?: string }>; details?: ReadToolDetails; isError?: boolean },
		options: RenderResultContextOptions,
		args?: ReadRenderArgs,
	): NativeToolView {
		const linkPath = readLinkTarget(options.renderContext?.rawDetails);
		const details = result.details;
		const rawPath = readRawPath(args);
		const routed = readUrlCard(rawPath, details);
		if (routed?.card.detailsKey === "proc") return describeProcRead(routed.target, result, details?.proc);
		if (routed) return describeCfgRead(splitInternalUrlSel(rawPath).path, result, details?.cfg);
		if (details?.kind === "url" || isReadableUrlPath(rawPath)) {
			return describeReadUrlResult({
				content: result.content,
				details: result.details as ReadUrlToolDetails | undefined,
				isError: result.isError,
			});
		}

		if (result.isError) {
			const message = (resultText(result) || "Unknown error").replace(/^Error:\s*/, "");
			return inlineErrorView(readNativeHead(rawPath, args, details, linkPath), message);
		}

		const suffix = details?.suffixResolution;
		const head = readNativeHead(rawPath, args, details, linkPath);
		const truncation = details?.meta?.truncation;
		const fallback = details?.truncation;
		const firstLineTooLong = truncation !== undefined && fallback?.firstLineExceedsLimit === true;
		const foot = footnoteText(
			compact([
				details?.resolvedPath !== undefined && `resolved ${shortenPath(details.resolvedPath)}`,
				firstLineTooLong &&
					`First line exceeds ${formatBytes(fallback.outputBytes ?? fallback.totalBytes)} limit${truncation.artifactId ? `. ${formatFullOutputReference(truncation.artifactId)}` : ""}`,
			]),
			firstLineTooLong ? { artifactError: details?.meta?.artifactError } : details?.meta,
		);

		const contentText = details?.displayContent?.text ?? stripOutputNotice(resultText(result), details?.meta);
		// A file Tern's media viewer shows (image, model, PDF, video, audio): the host loads it by path.
		const mediaPath = readMediaPath(options.renderContext?.rawDetails) ?? details?.mediaPath;
		const media = options.media && mediaPath ? nativeMediaNode(mediaPath, "media") : undefined;
		const imageBlock = result.content?.find(isImageBlock);
		if (imageBlock) {
			const detailText = contentText.trim();
			return {
				tool: head,
				tone: suffix ? "warning" : undefined,
				inline: true,
				body: compact<NativeChild>([
					media ?? describeReadImage(imageBlock, shortenPath(suffix?.to ?? splitReadRenderPath(rawPath).path)),
					detailText.length > 0 && ansi(detailText),
					foot,
				]),
			};
		}

		const renderPath = splitReadRenderPath(rawPath);
		const content: NativeChild[] = readResultIsMarkdown(details, args)
			? [md(contentText)]
			: readContentCode(
					contentText,
					details?.displayContent?.startLine ?? readRangeStart(rawPath, args),
					details?.displayContent?.lineNumbers,
					renderPath.path,
				);
		return { tool: head, inline: true, body: compact<NativeChild>([media, ...content, foot]) };
	},
	mergeCallAndResult: true,
} satisfies ToolRenderer<ReadRenderArgs, ReadToolDetails>;

/** Inclusive line range describing one elided span in a structural summary. */
export interface ElidedRange {
	start: number;
	end: number;
}

const BRACE_PAIRS: Record<string, string> = { "{": "}", "(": ")", "[": "]" };
const BRACE_TAIL_TRAILING_RE = /^[;,)\]}]*$/;

/**
 * Decide whether the kept lines surrounding an elided range collapse to a
 * single brace-pair line in the rendered summary. Returns true when the head
 * line ends with `{` / `(` / `[` and the tail line is the matching closer
 * (optionally followed by terminating punctuation like `;`, `,`, or further
 * closers — e.g. `};`, `})`, `]);`).
 */
export function canMergeBracePair(headLine: string, tailLine: string): boolean {
	const head = headLine.trimEnd();
	const tail = tailLine.trim();
	const opener = head.slice(-1);
	const closer = BRACE_PAIRS[opener];
	if (!closer) return false;
	if (!tail.startsWith(closer)) return false;
	return BRACE_TAIL_TRAILING_RE.test(tail.slice(closer.length));
}

/** Format one summary line with the selected line-prefix mode. */
export function formatSingleLine(
	line: number,
	text: string,
	shouldAddHashLines: boolean,
	shouldAddLineNumbers: boolean,
): string {
	if (shouldAddHashLines) return formatNumberedLine(line, text);
	if (shouldAddLineNumbers) return `${line}|${text}`;
	return text;
}

/** Format the boundary lines around an elided brace-pair body. */
export function formatMergedBraceLine(
	startLine: number,
	endLine: number,
	headText: string,
	tailText: string,
	shouldAddHashLines: boolean,
	shouldAddLineNumbers: boolean,
): { model: string; display: string } {
	const merged = `${headText.trimEnd()} … ${tailText.trim()}`;
	if (shouldAddHashLines) {
		return { model: `${startLine}-${endLine}:${merged}`, display: merged };
	}
	if (shouldAddLineNumbers) {
		return { model: `${startLine}-${endLine}|${merged}`, display: merged };
	}
	return { model: merged, display: merged };
}

/** Format a structural summary using the supplied file-display preferences. */
export function formatReadSummary(
	displayMode: { hashLines: boolean; lineNumbers: boolean },
	summary: SummaryResult,
): {
	text: string;
	displayText: string;
	elidedRanges: ElidedRange[];
	elidedLines: number;
} {
	const shouldAddHashLines = displayMode.hashLines;
	const shouldAddLineNumbers = shouldAddHashLines ? false : displayMode.lineNumbers;

	// Flatten segments into per-line units so we can merge a kept-head /
	// elided / kept-tail sandwich into a single brace-pair line when the
	// boundary lines look like `… {` and `}` (or matching variants).
	type Unit =
		| { kind: "line"; line: number; text: string }
		| { kind: "elided"; startLine: number; endLine: number }
		| {
				kind: "merged";
				startLine: number;
				endLine: number;
				headText: string;
				tailText: string;
		  };

	const raw: Unit[] = [];
	for (const segment of summary.segments) {
		if (segment.kind === "elided") {
			raw.push({ kind: "elided", startLine: segment.startLine, endLine: segment.endLine });
			continue;
		}
		const text = segment.text ?? "";
		if (text.length === 0) continue;
		const lines = text.split("\n");
		for (let i = 0; i < lines.length; i++) {
			raw.push({ kind: "line", line: segment.startLine + i, text: lines[i] });
		}
	}

	const units: Unit[] = [];
	let i = 0;
	while (i < raw.length) {
		const cur = raw[i];
		if (cur.kind === "elided") {
			const prev = units.length > 0 ? units[units.length - 1] : null;
			const next = i + 1 < raw.length ? raw[i + 1] : null;
			if (prev?.kind === "line" && next?.kind === "line" && canMergeBracePair(prev.text, next.text)) {
				units.pop();
				units.push({
					kind: "merged",
					startLine: prev.line,
					endLine: next.line,
					headText: prev.text,
					tailText: next.text,
				});
				i += 2;
				continue;
			}
		}
		units.push(cur);
		i++;
	}

	const modelParts: string[] = [];
	const displayParts: string[] = [];
	const elidedRanges: ElidedRange[] = [];
	let elidedLines = 0;
	for (const unit of units) {
		if (unit.kind === "elided") {
			modelParts.push("…");
			displayParts.push("…");
			elidedRanges.push({ start: unit.startLine, end: unit.endLine });
			elidedLines += unit.endLine - unit.startLine + 1;
			continue;
		}
		if (unit.kind === "merged") {
			const formatted = formatMergedBraceLine(
				unit.startLine,
				unit.endLine,
				unit.headText,
				unit.tailText,
				shouldAddHashLines,
				shouldAddLineNumbers,
			);
			modelParts.push(formatted.model);
			displayParts.push(formatted.display);
			// Suggest the full brace range so re-reading shows both braces
			// plus the elided body in one shot.
			elidedRanges.push({ start: unit.startLine, end: unit.endLine });
			// Merged brace pair encloses (start+1)..(end-1) as elided.
			elidedLines += Math.max(0, unit.endLine - unit.startLine - 1);
			continue;
		}
		modelParts.push(formatSingleLine(unit.line, unit.text, shouldAddHashLines, shouldAddLineNumbers));
		displayParts.push(unit.text);
	}

	return { text: modelParts.join("\n"), displayText: displayParts.join("\n"), elidedRanges, elidedLines };
}
