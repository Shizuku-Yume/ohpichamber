/**
 * Transcript renderer for the `find` tool (semantic grep). Hits are ranked
 * strongest first; each row carries a score gauge, the hyperlinked file, and
 * its strongest verified line ranges with a verbatim snippet.
 */
import * as path from "node:path";
import { formatDuration, formatNumber } from "@oh-my-pi/pi-utils";
import { renderProgressBar } from "../components/progress-bar";
import { Text } from "../components/text";
import { fileHyperlink, getTreeBranch, renderStatusLine, renderTreeList, uriHyperlink } from "../render";
import {
	createCachedComponent,
	FILE_NAME_COLOR,
	fitHeaderedRows,
	formatCount,
	formatEmptyMessage,
	formatErrorMessage,
	formatStyledPath,
	PREVIEW_LIMITS,
	replaceTabs,
} from "../render/render-utils";
import { getLanguageFromPath } from "../lang-from-path";
import { highlightCode, isHighlightLanguage, type Theme, type ThemeColor } from "../theme/theme";
import type { Component } from "../tui";
import type { OutputMeta } from "./output-meta";
import type {
	NativeToolHead,
	NativeToolView,
	RenderResultContextOptions,
	RenderResultOptions,
	ToolRenderer,
} from "./renderer";
import type { TspTone } from "@oh-my-pi/pi-wire";
import { code, col, compact, keyed, node, span, text } from "../native/describe";
import type { NativeChild, NativeNode } from "../native/node";
import { fileHref, fileRow, inlineErrorView } from "./native-view";
import { splitUrlScheme } from "./url-scheme-host";

/** A verified line range with its yes-probability and a one-line preview. */
export interface FindRange {
	start: number;
	end: number;
	p: number;
	snippet: string;
}

/** A file whose verified passages cleared the threshold; `ranges` are merged positive spans, strongest first. */
export interface FindHit {
	/** Display path relative to {@link FindToolDetails.cwd}, or an internal URL under URL scopes. */
	rel: string;
	/** Filename judgment, when the name batch answered. */
	nameScore?: number;
	/** Best verified passage probability. */
	contentScore: number;
	ranges: FindRange[];
	/** Lines of content actually judged, and whether the file held more. */
	linesSeen: number;
	truncated: boolean;
}

/**
 * How much of a search the judge actually covered. `unavailable`: every judge
 * request failed, so an empty result is not evidence of absence. `partial`:
 * some requests failed, or the call's deadline cut verification short.
 * `complete`: none failed (or none were needed).
 */
export type FindCoverage = "complete" | "partial" | "unavailable";

/** Verification cut short by the call's deadline: complete passages verified of those routed to it. */
export interface FindTimeout {
	verified: number;
	passages: number;
}

/** Search accounting reported alongside the hits. */
export interface FindStats {
	/** Eligible files under the root. */
	listed: number;
	requests: number;
	/** Judge requests that failed outright; decides {@link FindCoverage}. */
	failed: number;
	/** Questions a successful response left without a usable answer. */
	unanswered: number;
	/** Entries judged by name. */
	judged: number;
	/** Files whose content was read and sent. */
	filesRead: number;
	fileBytes: number;
	inputTokens: number;
	outputTokens: number;
	cost: number;
	apiMs: number;
	windowsJudged: number;
	windowsPruned: number;
	mapCards: number;
	/** Distinct request failures, phase-prefixed. */
	failures: string[];
}

/** Display metadata for find tool results. */
export interface FindToolDetails {
	query: string;
	/** Lexical keywords actually used: derived from the query plus `grep_keywords`. */
	keywords: string[];
	/** Verified-passage probability at or above which a file is a hit. */
	threshold: number;
	hits: FindHit[];
	coverage: FindCoverage;
	stats: FindStats;
	/** Set when the deadline ended verification; the hits are those verified before it. */
	timeout?: FindTimeout;
	elapsedMs: number;
	/** Session cwd; hit paths are relative to it. */
	cwd: string;
	/** Display form of the searched directory or file when narrower than cwd. */
	scopePath?: string;
	meta?: OutputMeta;
}

interface FindRenderArgs {
	query?: string;
	grep_keywords?: string[];
	path?: string;
}

/** Cells in the per-hit score gauge. */
const GAUGE_WIDTH = 6;
/** Hits shown before expansion. */
const COLLAPSED_HITS = 5;
/** Ranges shown per hit: one collapsed, three expanded. */
const RANGES_COLLAPSED = 1;
const RANGES_EXPANDED = 3;
/** Score at or above which a hit renders as strong / plausible. */
const STRONG = 0.7;
const PLAUSIBLE = 0.4;

function scoreColor(p: number): ThemeColor {
	return p >= STRONG ? "success" : p >= PLAUSIBLE ? "warning" : "muted";
}

function gauge(p: number, theme: Theme): string {
	const color = scoreColor(p);
	return renderProgressBar(p, GAUGE_WIDTH, {
		style: {
			filled: theme.symbol("progress.filled"),
			empty: theme.symbol("progress.empty"),
			styleFilled: text => theme.fg(color, text),
			styleEmpty: text => theme.fg("dim", text),
		},
	});
}

/** Raw metadata is used only for file link targets, never for displayed text. */
function findLinkTargets(details: FindToolDetails, rawDetails: unknown) {
	const raw = rawDetails !== null && typeof rawDetails === "object" ? rawDetails : undefined;
	const cwd = raw && "cwd" in raw && typeof raw.cwd === "string" ? raw.cwd : details.cwd;
	const rawHits: unknown[] = raw && "hits" in raw && Array.isArray(raw.hits) ? raw.hits : [];
	return {
		cwd,
		rel(hit: FindHit, index: number): string {
			const candidate = rawHits[index];
			return candidate !== null &&
				typeof candidate === "object" &&
				"rel" in candidate &&
				typeof candidate.rel === "string"
				? candidate.rel
				: hit.rel;
		},
	};
}

function renderHit(hit: FindHit, rangeLimit: number, cwd: string | undefined, rawRel: string, theme: Theme): string[] {
	// `scheme://` hits (e.g. virtual docs) are not files under `cwd`: link the
	// URL itself instead of joining it onto a filesystem base.
	const isUrlHit = splitUrlScheme(hit.rel) !== undefined;
	const link = (text: string, line?: number): string => {
		if (isUrlHit) return uriHyperlink(line === undefined ? hit.rel : `${hit.rel}:${line}`, text);
		const absPath = cwd === undefined ? undefined : path.join(cwd, rawRel);
		return absPath === undefined ? text : fileHyperlink(absPath, text, { line });
	};
	const coverage = hit.truncated ? `${hit.linesSeen} lines judged, partial` : `${hit.linesSeen} lines judged`;
	// URL hits show whole in the file-name color; file hits get the dim directory.
	const label = isUrlHit ? theme.fg(FILE_NAME_COLOR, hit.rel) : formatStyledPath(hit.rel, theme);
	const score = theme.fg(scoreColor(hit.contentScore), hit.contentScore.toFixed(2));
	const lines = [`${gauge(hit.contentScore, theme)} ${score} ${link(label)} ${theme.fg("dim", coverage)}`];
	const ranges = [...hit.ranges].sort((a, b) => b.p - a.p || a.start - b.start).slice(0, rangeLimit);
	const lang = getLanguageFromPath(hit.rel);
	ranges.forEach((range, index) => {
		const span = range.start === range.end ? String(range.start) : `${range.start}-${range.end}`;
		const ref = link(theme.fg("muted", `:${span}`), range.start);
		const source = replaceTabs(range.snippet.trim());
		const snippet = isHighlightLanguage(lang)
			? highlightCode(source, lang, theme).join("\n")
			: theme.fg("toolOutput", source);
		const branch = theme.fg("dim", getTreeBranch(index === ranges.length - 1, theme));
		lines.push(`  ${branch} ${ref} ${theme.fg("dim", range.p.toFixed(2))} ${snippet}`);
	});
	return lines;
}

function scoreTone(p: number): TspTone {
	return p >= STRONG ? "success" : p >= PLAUSIBLE ? "warning" : "muted";
}

/**
 * One hit (§7.3 find): a 22px row of the score bar, the path and `12 lines
 * judged`, then its strongest ranges as numbered `code` (no path header).
 */
function describeHit(hit: FindHit, rangeLimit: number, cwd: string | undefined, rawRel: string): NativeNode {
	const ranges = [...hit.ranges].sort((a, b) => b.p - a.p || a.start - b.start).slice(0, rangeLimit);
	const tone = scoreTone(hit.contentScore);
	const score = hit.contentScore.toFixed(2);
	const isUrlHit = splitUrlScheme(hit.rel) !== undefined;
	const head = fileRow(hit.rel, {
		lead: node("progress", { value: hit.contentScore, tone, title: `score ${score}`, max: { w: 40 } }),
		detail: [
			span(score, tone),
			span(
				hit.truncated ? ` · ${hit.linesSeen} lines judged, partial` : ` · ${hit.linesSeen} lines judged`,
				"muted",
			),
		],
		href: isUrlHit || cwd === undefined ? undefined : fileHref(path.join(cwd, rawRel)),
		key: "hit",
	});
	const snippets = ranges.map(range =>
		keyed(
			code(range.snippet.trimEnd(), {
				path: hit.rel,
				start: range.start,
				numbers: true,
				title: range.p.toFixed(2),
			}),
			`${range.start}-${range.end}`,
		),
	);
	return keyed(col([head, ...snippets], { gap: "xs", role: "omp.tool.find.hit" }), hit.rel);
}

/** Native find head: the query, then `meta` (result counts), or the call's keywords and scope. */
function findNativeHead(
	query: string | undefined,
	meta: readonly NonNullable<NativeToolHead["meta"]>[number][],
): NativeToolHead {
	return { title: "Find", target: query ?? "", targetKind: "query", meta };
}

function quoteQuery(query: string | undefined): string | undefined {
	return query === undefined ? undefined : `"${query}"`;
}

/** Render find calls and results in the transcript. */
export const findToolRenderer = {
	renderCall(args: FindRenderArgs, options: RenderResultOptions, uiTheme: Theme): Component {
		const keywords = args.grep_keywords ?? [];
		const meta = keywords.length > 0 ? [keywords.join(" ")] : [];
		if (args.path) meta.push(`in ${args.path}`);
		const text = renderStatusLine(
			{
				icon: "pending",
				spinnerFrame: options.spinnerFrame,
				title: "Find",
				titleColor: "toolTitle",
				description: quoteQuery(args.query),
				meta,
			},
			uiTheme,
		);
		return new Text(text, 0, 0);
	},

	renderResult(
		result: { content: Array<{ type: string; text?: string }>; details?: FindToolDetails; isError?: boolean },
		options: RenderResultContextOptions,
		uiTheme: Theme,
		args?: FindRenderArgs,
	): Component {
		const details = result.details;
		const text = result.content?.find(c => c.type === "text")?.text ?? "";

		if (result.isError) {
			return new Text(formatErrorMessage(text || "Unknown error", uiTheme), 0, 0);
		}

		// Streaming progress: the tool reports the phase it is in.
		if (options.isPartial || details === undefined) {
			const header = renderStatusLine(
				{
					icon: "pending",
					spinnerFrame: options.spinnerFrame,
					title: "Find",
					titleColor: "toolTitle",
					description: quoteQuery(args?.query ?? details?.query),
					meta: text ? [text] : [],
				},
				uiTheme,
			);
			return new Text(header, 0, 0);
		}

		const { hits, stats, threshold } = details;
		const linkTargets = findLinkTargets(details, options.renderContext?.rawDetails);
		const description = quoteQuery(details.query);
		const scope = details.scopePath === undefined ? [] : [`in ${details.scopePath}`];
		const meta = [
			formatCount("hit", hits.length),
			...scope,
			`${stats.filesRead} files read`,
			`τ ${threshold.toFixed(2)}`,
			`${formatNumber(stats.inputTokens)} tokens`,
			`$${stats.cost.toFixed(4)}`,
			formatDuration(details.elapsedMs),
		];
		const failed = stats.failed > 0 ? `${stats.failed}/${stats.requests} requests failed` : undefined;
		if (failed) meta.push(uiTheme.fg("warning", failed));
		const { timeout } = details;
		if (timeout)
			meta.push(uiTheme.fg("warning", `timed out, ${timeout.verified}/${timeout.passages} passages verified`));

		if (hits.length === 0) {
			const emptyMeta = ["0 hits", ...scope, `$${stats.cost.toFixed(4)}`, formatDuration(details.elapsedMs)];
			if (failed) emptyMeta.push(uiTheme.fg("warning", failed));
			const header = renderStatusLine(
				{ icon: "warning", title: "Find", titleColor: "toolTitle", description, meta: emptyMeta },
				uiTheme,
			);
			const empty =
				details.coverage === "partial"
					? "No relevant passages found in the judged files"
					: "No relevant passages found";
			const lines = [header, formatEmptyMessage(empty, uiTheme)];
			for (const failure of stats.failures) lines.push(uiTheme.fg("warning", failure));
			return new Text(lines.join("\n"), 0, 0);
		}

		const header = renderStatusLine(
			{
				iconOverride: uiTheme.fg("toolTitle", uiTheme.symbol("icon.search")),
				title: "Find",
				titleColor: "toolTitle",
				description,
				meta,
			},
			uiTheme,
		);

		return createCachedComponent(
			() => options.expanded,
			(width, expanded) => {
				const hitLines = renderTreeList(
					{
						items: hits,
						expanded,
						maxCollapsed: COLLAPSED_HITS,
						maxCollapsedLines: PREVIEW_LIMITS.EXPANDED_LINES,
						itemType: "hit",
						renderItem: (hit, context) =>
							renderHit(
								hit,
								expanded ? RANGES_EXPANDED : RANGES_COLLAPSED,
								linkTargets.cwd,
								linkTargets.rel(hit, context.index),
								uiTheme,
							),
					},
					uiTheme,
				);
				const extra: string[] = [];
				if (expanded) {
					extra.push(uiTheme.fg("dim", `keywords: ${details.keywords.join(", ")}`));
					for (const failure of stats.failures) extra.push(uiTheme.fg("warning", failure));
				}
				return fitHeaderedRows(header, [...hitLines, ...extra], width);
			},
		);
	},
	describeCall(args: FindRenderArgs): NativeToolView {
		const keywords = args.grep_keywords ?? [];
		return {
			tool: findNativeHead(
				args.query,
				compact([keywords.length > 0 && keywords.join(" "), args.path && `in ${args.path}`]),
			),
			inline: true,
		};
	},

	/**
	 * Inline (§7.3 find): `Find “query”  2 hits · 8 files`, then per hit its
	 * score bar, path and coverage over the strongest snippets. The search
	 * accounting (τ, tokens, cost, time) is the footnote's tooltip.
	 */
	describeResult(
		result: { content: Array<{ type: string; text?: string }>; details?: FindToolDetails; isError?: boolean },
		options: RenderResultContextOptions,
		args?: FindRenderArgs,
	): NativeToolView {
		const details = result.details;
		const progress = result.content?.find(c => c.type === "text")?.text ?? "";
		const query = args?.query ?? details?.query;
		if (result.isError) return inlineErrorView(findNativeHead(query, []), progress || "Unknown error");
		if (options.isPartial || details === undefined) {
			return {
				tool: findNativeHead(query, progress ? [[span(progress, "muted", { fx: "shimmer" })]] : []),
				inline: true,
			};
		}
		const { hits, stats, threshold } = details;
		const linkTargets = findLinkTargets(details, options.renderContext?.rawDetails);
		const scope = details.scopePath === undefined ? undefined : `in ${details.scopePath}`;
		const failed =
			stats.failed > 0 ? [span(`${stats.failed}/${stats.requests} requests failed`, "warning")] : undefined;
		const { timeout } = details;
		const timedOut = timeout
			? [span(`timed out, ${timeout.verified}/${timeout.passages} passages verified`, "warning")]
			: undefined;
		const accounting = [
			`${stats.filesRead} files read`,
			`τ ${threshold.toFixed(2)}`,
			`${formatNumber(stats.inputTokens)} tokens`,
			`$${stats.cost.toFixed(4)}`,
			formatDuration(details.elapsedMs),
		].join(" · ");
		const failures = stats.failures.map((failure, i) =>
			keyed(text([span(failure, "warning")], { wrap: "word", role: "omp.tool.notice" }), `fail${i}`),
		);
		if (hits.length === 0) {
			return {
				tool: findNativeHead(query, compact(["0 hits", scope, failed])),
				tone: "warning",
				inline: true,
				body: failures.length > 0 ? failures : undefined,
			};
		}
		const shown = options.expanded ? hits : hits.slice(0, COLLAPSED_HITS);
		const rangeLimit = options.expanded ? RANGES_EXPANDED : RANGES_COLLAPSED;
		const hidden = hits.length - shown.length;
		const footParts = compact([
			hidden > 0 && formatCount("more hit", hidden),
			`keywords: ${details.keywords.join(", ")}`,
		]);
		// One quiet last line; the accounting ANSI prints in the head rides its tooltip.
		const foot = keyed(
			text([span(footParts.join(" · "), "muted")], { wrap: "word", role: "omp.tool.stats", title: accounting }),
			"foot",
		);
		return {
			tool: findNativeHead(
				query,
				compact([
					`${formatCount("hit", hits.length)} · ${formatCount("file", stats.filesRead)}`,
					scope,
					failed,
					timedOut,
				]),
			),
			inline: true,
			body: compact<NativeChild>([
				...shown.map((hit, index) => describeHit(hit, rangeLimit, linkTargets.cwd, linkTargets.rel(hit, index))),
				...failures,
				foot,
			]),
			preview: { lines: PREVIEW_LIMITS.EXPANDED_LINES },
		};
	},
	mergeCallAndResult: true,
	animatedPendingPreview: true,
	animatedPartialResult: true,
} satisfies ToolRenderer<FindRenderArgs, FindToolDetails>;
