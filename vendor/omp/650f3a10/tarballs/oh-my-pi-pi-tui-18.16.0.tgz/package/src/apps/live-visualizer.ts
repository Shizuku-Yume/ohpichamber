import { formatKeyHint } from "../app-keybindings";
import type { Component } from "../tui";
import { OverlayPanel, PanelRows } from "../chrome/overlay-box";
import { type KeyId, matchesKey } from "../keys";
import { sliceWithWidth, truncateToWidth, visibleWidth } from "../utils";
import { sanitizeDisplaySingleLine } from "../overlays/extensions/display-text";
import { type ThemeColor, theme } from "../theme/theme";
import type { TspTone } from "@oh-my-pi/pi-wire";
import { card, node, row, span, text } from "../native/describe";
import type { DescribeContext, NativeNode, NativeUiEvent } from "../native/node";
import { actionBar, actionButton } from "../native/overlay";
import { Memo } from "../native/memo";

/** Distinct states of a realtime call connection. */
export type LivePhase = "connecting" | "listening" | "working" | "speaking" | "muted" | "error";

const PHASE_ICONS: Record<LivePhase, string> = {
	connecting: "○",
	listening: "●",
	working: "○",
	speaking: "»",
	muted: "×",
	error: "!",
};
const PHASE_COLORS: Record<LivePhase, ThemeColor> = {
	connecting: "dim",
	listening: "success",
	working: "warning",
	speaking: "accent",
	muted: "dim",
	error: "error",
};
const PHASE_TONES: Record<LivePhase, TspTone> = {
	connecting: "muted",
	listening: "success",
	working: "warning",
	speaking: "accent",
	muted: "muted",
	error: "error",
};
const SPECTRUM_BLOCKS = [" ", "▁", "▂", "▃", "▄", "▅", "▆", "▇", "█"] as const;
/** Native mic meter resolution: the level snaps to 1/20 steps so decay ticks don't rebuild every frame. */
const METER_STEPS = 20;

/** Configuration callbacks for user interactions in the visualizer. */
export interface LiveVisualizerOptions {
	onStop(): void;
	onToggleMute(): void;
	/** Configured `app.live.toggle` chords that also end the call (Ctrl+L by default). */
	stopKeys?: readonly KeyId[];
}

function truncateFromStart(text: string, width: number): string {
	if (width <= 0) return "";
	const textWidth = visibleWidth(text);
	if (textWidth <= width) return text;
	if (width === 1) return "…";
	return `…${sliceWithWidth(text, textWidth - width + 1, width - 1, true).text}`;
}

/** A compact, fixed-height terminal component for displaying a realtime call. */
export class LiveVisualizer implements Component {
	readonly wantsKeyRelease = false;

	readonly #options: LiveVisualizerOptions;
	readonly #body = new PanelRows();
	readonly #panel = new OverlayPanel();

	#phase: LivePhase = "connecting";
	#inputLevel = 0;
	#displayLevel = 0;
	#frame = 0;
	#userTranscript = "";
	readonly #native = new Memo();

	#cache:
		| {
				width: number;
				phase: LivePhase;
				displayLevel: number;
				frame: number;
				userTranscript: string;
				lines: readonly string[];
		  }
		| undefined;

	constructor(options: LiveVisualizerOptions) {
		this.#options = options;
		this.#body.setHeight(3);
		this.#panel.addChild(this.#body);
	}

	/** Updates the current call phase. */
	setPhase(phase: LivePhase): void {
		if (this.#phase !== phase) {
			this.#phase = phase;
			this.invalidate();
		}
	}

	/** Updates the microphone volume level (0..1). */
	setInputLevel(level: number): void {
		const next = Number.isFinite(level) ? Math.min(1, Math.max(0, level)) : 0;
		if (this.#inputLevel === next) return;
		this.#inputLevel = next;
		if (next > this.#displayLevel) this.#displayLevel = next;
		this.invalidate();
	}

	/** Advances the spectrum animation and its peak decay. */
	setFrame(frame: number): void {
		const nextLevel = Math.max(this.#inputLevel, this.#displayLevel * 0.84);
		if (this.#frame !== frame || this.#displayLevel !== nextLevel) {
			this.#frame = frame;
			this.#displayLevel = nextLevel;
			this.invalidate();
		}
	}

	/** Updates the user's streaming voice transcript. */
	setTranscript(text: string): void {
		const normalized = sanitizeDisplaySingleLine(text).replace(/\s+/g, " ").trim();
		if (this.#userTranscript === normalized) return;
		this.#userTranscript = normalized;
		this.invalidate();
	}

	/** Clears the user's voice transcript row. */
	clearTranscript(): void {
		if (!this.#userTranscript) return;
		this.#userTranscript = "";
		this.invalidate();
	}

	/** Processes user keypresses. */
	handleInput(data: string): void {
		if (
			matchesKey(data, "escape") ||
			matchesKey(data, "ctrl+c") ||
			this.#options.stopKeys?.some(key => matchesKey(data, key))
		) {
			this.#options.onStop();
		} else if (matchesKey(data, "space")) {
			this.#options.onToggleMute();
		}
	}

	/** Clears the render cache. */
	invalidate(): void {
		this.#cache = undefined;
		this.#panel.invalidate();
	}

	/** The call panel's buttons run the same code as their keys. */
	handleNativeEvent(event: NativeUiEvent): void {
		if (event.type !== "action") return;
		if (event.act === "mute") this.#options.onToggleMute();
		else if (event.act === "end") this.#options.onStop();
	}

	/**
	 * Native call panel: phase status (a spinner while working), the mic level
	 * as a `meter` (a `progress` bar on terminals without it), the streaming
	 * transcript and the Mute/End buttons. The spectrum animation is
	 * ANSI-only; frame ticks leave this node unchanged.
	 */
	describe(cx: DescribeContext): NativeNode {
		const energy = this.#phase === "muted" ? 0 : Math.min(1, Math.sqrt(this.#displayLevel * 5));
		const level = Math.round(energy * METER_STEPS) / METER_STEPS;
		const meter = cx.supports("meter");
		return this.#native.get([this.#phase, level, this.#userTranscript, meter], () => {
			const phase = this.#phase;
			const status =
				phase === "working"
					? node("spinner", { label: [span(phase, PHASE_COLORS[phase])], tone: PHASE_TONES[phase] })
					: text([span(`${PHASE_ICONS[phase]} ${phase}`, PHASE_COLORS[phase])]);
			const tone = phase === "muted" ? "muted" : phase === "error" ? "error" : "success";
			return card({ role: "omp.app.live", tone: PHASE_TONES[phase] }, [
				node("row", { gap: "sm", align: "center" }, [status], "head"),
				meter
					? row(
							[
								text([span("mic", "muted")]),
								node("meter", { value: level, style: "bar", size: "md", tone, grow: 1 }),
							],
							{
								gap: "sm",
								align: "center",
								role: "omp.app.live.level",
							},
						)
					: node("progress", { value: level, tone, label: [span("mic", "muted")] }),
				text([span(this.#userTranscript, "accent")], { wrap: "none", truncate: "start" }),
				actionBar([
					null,
					actionButton(phase === "muted" ? "Unmute" : "Mute", "mute", { keys: "space" }),
					actionButton("End call", "end", { keys: "escape", tone: "error" }),
				]),
			]);
		});
	}

	/** Renders the microphone spectrum into a compact fixed-height panel. */
	render(width: number): readonly string[] {
		if (
			this.#cache &&
			this.#cache.width === width &&
			this.#cache.phase === this.#phase &&
			this.#cache.displayLevel === this.#displayLevel &&
			this.#cache.frame === this.#frame &&
			this.#cache.userTranscript === this.#userTranscript
		) {
			return this.#cache.lines;
		}

		const lines = this.#renderLines(width);
		this.#cache = {
			width,
			phase: this.#phase,
			displayLevel: this.#displayLevel,
			frame: this.#frame,
			userTranscript: this.#userTranscript,
			lines,
		};
		return lines;
	}

	#renderLines(maxWidth: number): readonly string[] {
		const width = Math.max(2, maxWidth);
		const spectrumColor: ThemeColor = this.#phase === "muted" ? "dim" : this.#phase === "error" ? "error" : "success";
		if (width < 4) {
			const innerWidth = width - 2;
			const border = (content: string): string =>
				theme.fg("border", "│") + content + (width > 1 ? theme.fg("border", "│") : "");
			const top = theme.fg("border", `┌${"─".repeat(innerWidth)}${width > 1 ? "┐" : ""}`);
			const spectrum = this.#generateSpectrum(innerWidth, 2);
			return [
				top,
				...spectrum.map(row => border(theme.fg(spectrumColor, row))),
				border(this.#renderTranscript(this.#userTranscript, innerWidth)),
				this.#renderFooter(width, innerWidth),
			];
		}

		const contentWidth = width - 4;
		const spectrum = this.#generateSpectrum(contentWidth, 2);
		this.#body.setLines([
			...spectrum.map(row => theme.fg(spectrumColor, row)),
			this.#renderTranscript(this.#userTranscript, contentWidth),
		]);
		const lines = [...this.#panel.render(width)];
		lines[lines.length - 1] = this.#renderFooter(width, width - 2);
		return lines;
	}

	#renderTranscript(transcript: string, width: number): string {
		const content = truncateFromStart(transcript, width);
		const padding = " ".repeat(Math.max(0, width - visibleWidth(content)));
		return theme.fg("accent", content) + padding;
	}

	#renderFooter(width: number, innerWidth: number): string {
		const frames = theme.spinnerFrames;
		const icon = this.#phase === "working" ? frames[this.#frame % frames.length] : PHASE_ICONS[this.#phase];
		const status = `${icon} ${this.#phase}`;
		const fullLabel = ` ${status} · ${formatKeyHint("space")} mute · ${formatKeyHint("escape")} end `;
		const shortLabel = ` ${status} `;
		const label =
			innerWidth >= visibleWidth(fullLabel) + 1
				? fullLabel
				: innerWidth >= visibleWidth(shortLabel) + 1
					? shortLabel
					: "";
		const box = width >= 4 ? theme.boxRound : undefined;
		const bottomLeft = box?.bottomLeft ?? "└";
		const horizontal = box?.horizontal ?? "─";
		const bottomRight = box?.bottomRight ?? "┘";
		if (!label) {
			return theme.fg("border", `${bottomLeft}${horizontal.repeat(innerWidth)}${width > 1 ? bottomRight : ""}`);
		}
		const remaining = Math.max(0, innerWidth - visibleWidth(label) - 1);
		return (
			theme.fg("border", `${bottomLeft}${horizontal}`) +
			theme.fg(PHASE_COLORS[this.#phase], truncateToWidth(label, innerWidth - 1)) +
			theme.fg("border", `${horizontal.repeat(remaining)}${width > 1 ? bottomRight : ""}`)
		);
	}

	#generateSpectrum(width: number, rows: number): string[] {
		const output = Array.from({ length: rows }, () => "");
		const energy = this.#phase === "muted" ? 0 : Math.min(1, Math.sqrt(this.#displayLevel * 5));
		const maxHeight = rows * (SPECTRUM_BLOCKS.length - 1);
		for (let column = 0; column < width; column += 1) {
			const carrier = 0.5 + 0.5 * Math.sin(this.#frame * 0.43 + column * 0.71);
			const shimmer = 0.5 + 0.5 * Math.sin(this.#frame * 0.19 - column * 1.17);
			const height = Math.round(energy * (0.3 + carrier * 0.5 + shimmer * 0.2) * maxHeight);
			for (let row = 0; row < rows; row += 1) {
				const units = Math.max(0, Math.min(SPECTRUM_BLOCKS.length - 1, height - (rows - row - 1) * 8));
				output[row] += SPECTRUM_BLOCKS[units];
			}
		}
		return output;
	}
}
