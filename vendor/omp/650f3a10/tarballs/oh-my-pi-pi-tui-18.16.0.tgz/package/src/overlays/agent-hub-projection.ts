import type { AgentMetricsSummary, AgentRecordLike, AgentStatus } from "./agent-hub-types";
import { MAIN_AGENT_ID } from "./agent-hub-types";
import type { ObservableSession } from "./session-observer-registry";

export type AgentMetrics = AgentMetricsSummary;

export interface AgentCostSnapshot {
	cost: number | undefined;
}

export interface AggregateMetrics extends AgentMetrics {
	reportedAgents: number;
	/** Rows whose duration is an observer-measured active runtime. */
	activeDurationAgents: number;
}

interface AgentTreeProjection<TRecord extends AgentRecordLike> {
	rows: TRecord[];
	depthById: Map<string, number>;
	parentById: Map<string, string>;
	lastSiblingById: Map<string, boolean>;
}

export const STATUS_ORDER: Record<AgentStatus, number> = { running: 0, idle: 1, parked: 2, aborted: 3 };

function finiteMetric(value: number | undefined): number {
	return typeof value === "number" && Number.isFinite(value) ? value : 0;
}

/** Message list a fallback metrics read was taken from; unchanged list ⇒ unchanged metrics. */
interface FallbackReadStamp {
	messages: readonly unknown[];
	length: number;
	last: unknown;
	/** Usage and block count of the last message, which a streaming turn mutates in place. */
	lastShape: string;
	/** Session model, whose context window the context gauge reports. */
	model: unknown;
	contextWindow: number | null | undefined;
}

/** Stamp of each cached fallback read, keyed by the cache entry so it cannot outlive that read. */
const fallbackReadStamps = new WeakMap<object, FallbackReadStamp>();

function lastMessageShape(last: unknown): string {
	if (!last || typeof last !== "object") return "";
	const { usage, content } = last as {
		usage?: { input?: number; output?: number; cacheWrite?: number; cost?: { total?: number } };
		content?: unknown;
	};
	const blocks = Array.isArray(content) ? content.length : -1;
	return `${usage?.input}:${usage?.output}:${usage?.cacheWrite}:${usage?.cost?.total}:${blocks}`;
}

function fallbackReadStamp(session: NonNullable<AgentRecordLike["session"]>): FallbackReadStamp | undefined {
	try {
		const messages = session.agent?.state?.messages;
		if (!Array.isArray(messages)) return undefined;
		const last = messages[messages.length - 1];
		return {
			messages,
			length: messages.length,
			last,
			lastShape: lastMessageShape(last),
			model: session.model,
			contextWindow: session.model?.contextWindow,
		};
	} catch {
		return undefined;
	}
}

/**
 * Whether a cached fallback read still matches the session's message list
 * (append, compaction, rewrite, streaming tail) and model (context window).
 */
function fallbackReadCurrent(entry: object, session: NonNullable<AgentRecordLike["session"]>): boolean {
	const stamp = fallbackReadStamps.get(entry);
	if (!stamp) return false;
	const current = fallbackReadStamp(session);
	return (
		current !== undefined &&
		current.messages === stamp.messages &&
		current.length === stamp.length &&
		current.last === stamp.last &&
		current.lastShape === stamp.lastShape &&
		current.model === stamp.model &&
		current.contextWindow === stamp.contextWindow
	);
}

/** Exact observer usage for one roster entry. */
export function progressMetrics(observed: ObservableSession | undefined): AgentMetrics | undefined {
	const progress = observed?.progress;
	if (!progress) return undefined;
	const { tokens, requests, toolCount: tools, cost, durationMs } = progress;
	if (
		typeof tokens !== "number" ||
		!Number.isFinite(tokens) ||
		typeof requests !== "number" ||
		!Number.isFinite(requests) ||
		typeof tools !== "number" ||
		!Number.isFinite(tools) ||
		typeof cost !== "number" ||
		!Number.isFinite(cost) ||
		typeof durationMs !== "number" ||
		!Number.isFinite(durationMs)
	) {
		return undefined;
	}
	return {
		tokens,
		requests,
		tools,
		cost,
		durationMs,
		durationKind: "active",
		contextTokens:
			typeof progress.contextTokens === "number" && Number.isFinite(progress.contextTokens)
				? progress.contextTokens
				: undefined,
		contextWindow:
			typeof progress.contextWindow === "number" && Number.isFinite(progress.contextWindow)
				? progress.contextWindow
				: undefined,
	};
}

/** Lifetime cost from the authoritative session index, excluding task-result child billing. */
function readSessionDirectCost(session: NonNullable<AgentRecordLike["session"]>): number | undefined {
	try {
		const usage = session.sessionManager?.getUsageStatistics();
		if (
			usage &&
			Number.isFinite(usage.cost) &&
			Number.isFinite(usage.subagentCost) &&
			usage.cost >= usage.subagentCost
		) {
			return usage.cost - usage.subagentCost;
		}
	} catch {
		// A session stopping during render may have already closed its stats host.
	}
	return undefined;
}

/**
 * Read direct assistant usage from a live session. SessionStats also includes
 * usage embedded in completed `task` tool results, so using it for a parent
 * row would double-count child rows in the aggregate.
 */
function readSessionMetrics(
	session: NonNullable<AgentRecordLike["session"]>,
	directCost: number | undefined,
): AgentMetrics | undefined {
	try {
		const stats = session.getSessionStats();
		const messages = session.agent?.state?.messages;
		if (!Array.isArray(messages)) {
			return {
				tokens: stats.tokens.input + stats.tokens.output + stats.tokens.cacheWrite,
				requests: stats.assistantMessages,
				tools: stats.toolCalls,
				cost: directCost ?? stats.cost,
				durationMs: 0,
				durationKind: "unknown",
				contextTokens: stats.contextUsage?.tokens,
				contextWindow: stats.contextUsage?.contextWindow,
			};
		}

		let tokens = 0;
		let requests = 0;
		let tools = 0;
		let cost = 0;
		for (const message of messages) {
			if (message.role !== "assistant") continue;
			requests++;
			tokens += message.usage.input + message.usage.output + message.usage.cacheWrite;
			tools += message.content.filter(content => content.type === "toolCall").length;
			cost += message.usage.cost.total;
		}
		return {
			tokens,
			requests,
			tools,
			cost: directCost ?? cost,
			durationMs: 0,
			durationKind: "unknown",
			contextTokens: stats.contextUsage?.tokens,
			contextWindow: stats.contextUsage?.contextWindow,
		};
	} catch {
		// Render-only doubles and sessions being torn down may not expose a
		// complete statistics host. Missing metrics are preferable to a broken hub.
		return undefined;
	}
}

/** Live session used to cache a row's direct assistant usage, including with observer progress. */
export function hubFallbackStatsSession<TRecord extends AgentRecordLike>(
	ref: TRecord,
	observed: ObservableSession | undefined,
): NonNullable<TRecord["session"]> | undefined {
	void observed;
	const session = ref.session;
	return session && typeof session.getSessionStats === "function" ? session : undefined;
}

/**
 * Shared row policy for the Agent Hub and the status-line cost total.
 * Non-cost metrics come from live progress, then persisted history, then the retained
 * snapshot (parked rows only), then the live session. Cost always overlays the cumulative
 * direct-session bill: live, then `history.directCost` (written at park), then retained.
 * Persisted `history.metrics.cost` is a leaf-scoped snapshot, so it never wins.
 */
function projectRowMetrics<TMetrics extends AgentCostSnapshot>(
	ref: AgentRecordLike,
	observed: ObservableSession | undefined,
	live: TMetrics | undefined,
	retained: TMetrics | undefined,
	hasLiveSession: boolean,
): TMetrics | AgentMetrics | undefined {
	const cost = live?.cost ?? ref.history?.directCost ?? retained?.cost;
	const metrics = observed?.progress
		? progressMetrics(observed)
		: (ref.history?.metrics ?? (!hasLiveSession ? retained : undefined) ?? live);
	return metrics && cost !== undefined ? { ...metrics, cost } : metrics;
}

/** Full Agent Hub row metrics; see {@link projectRowMetrics} for source precedence. */
export function hubRowMetrics<TRecord extends AgentRecordLike>(
	ref: TRecord,
	observed: ObservableSession | undefined,
	sessionMetrics: WeakMap<object, { metrics: AgentMetrics | undefined }>,
): AgentMetrics | undefined {
	const session = hubFallbackStatsSession(ref, observed);
	const liveEntry = session ? sessionMetrics.get(session) : undefined;
	const retainedEntry = sessionMetrics.get(ref);
	return projectRowMetrics(ref, observed, liveEntry?.metrics, retainedEntry?.metrics, session !== undefined);
}

/** Cost-only projection for frequent status updates; full roster metrics keep their own cache. */
export function aggregateCost<TRecord extends AgentRecordLike>(args: {
	rows: readonly TRecord[];
	observedById: ReadonlyMap<string, ObservableSession>;
	sessionCosts: WeakMap<object, AgentCostSnapshot>;
}): number {
	let total = 0;
	const countedSessions = new Set<NonNullable<AgentRecordLike["session"]>>();
	for (const ref of args.rows) {
		const observed = args.observedById.get(ref.id);
		const session = hubFallbackStatsSession(ref, observed);
		let cached = session ? args.sessionCosts.get(session) : undefined;
		if (session) {
			const directCost = readSessionDirectCost(session);
			if (directCost !== undefined) {
				cached = { cost: directCost };
				args.sessionCosts.set(session, cached);
			} else if (!cached || !fallbackReadCurrent(cached, session)) {
				const stamp = fallbackReadStamp(session);
				cached = { cost: readSessionMetrics(session, undefined)?.cost };
				if (stamp) fallbackReadStamps.set(cached, stamp);
				args.sessionCosts.set(session, cached);
			}
			if (cached?.cost !== undefined) args.sessionCosts.set(ref, cached);
		}
		const cost = projectRowMetrics(
			ref,
			observed,
			cached?.cost !== undefined ? cached : undefined,
			args.sessionCosts.get(ref),
			session !== undefined,
		)?.cost;
		if (cost === undefined || (session && countedSessions.has(session))) continue;
		if (session) countedSessions.add(session);
		total += finiteMetric(cost);
	}
	return total;
}

export function aggregateMetrics<TRecord extends AgentRecordLike>(args: {
	rows: readonly TRecord[];
	observedById: ReadonlyMap<string, ObservableSession>;
	metricsFor: (ref: TRecord, observed: ObservableSession | undefined) => AgentMetrics | undefined;
	fallbackStatsSession: (
		ref: TRecord,
		observed: ObservableSession | undefined,
	) => NonNullable<AgentRecordLike["session"]> | undefined;
	sessionMetrics: WeakMap<object, { metrics: AgentMetrics | undefined }>;
	refreshFallback: boolean;
}): { metrics: AggregateMetrics; hasFallbackLiveSessions: boolean } {
	const total: AggregateMetrics = {
		tokens: 0,
		requests: 0,
		tools: 0,
		cost: 0,
		durationMs: 0,
		durationKind: "active",
		reportedAgents: 0,
		activeDurationAgents: 0,
	};
	let hasFallbackLiveSessions = false;
	const countedFallbackSessions = new Set<NonNullable<AgentRecordLike["session"]>>();
	for (const ref of args.rows) {
		const observed = args.observedById.get(ref.id);
		const fallbackSession = args.fallbackStatsSession(ref, observed);
		if (fallbackSession) {
			hasFallbackLiveSessions = true;
			let cached = args.sessionMetrics.get(fallbackSession);
			const directCost = readSessionDirectCost(fallbackSession);
			// Refresh cost independently from the message scan: model_usage entries
			// are cumulative but do not alter the agent's live message list.
			if (!cached || (args.refreshFallback && !fallbackReadCurrent(cached, fallbackSession))) {
				const stamp = fallbackReadStamp(fallbackSession);
				const entry = { metrics: readSessionMetrics(fallbackSession, directCost) };
				if (stamp) fallbackReadStamps.set(entry, stamp);
				args.sessionMetrics.set(fallbackSession, entry);
				cached = entry;
			} else if (cached.metrics && directCost !== undefined) {
				cached.metrics.cost = directCost;
			}
			// Preserve valid direct-session snapshots through parking or a failed teardown read.
			if (cached.metrics) args.sessionMetrics.set(ref, cached);
		}
		const metrics = args.metricsFor(ref, observed);
		if (!metrics || (fallbackSession && countedFallbackSessions.has(fallbackSession))) continue;
		if (fallbackSession) countedFallbackSessions.add(fallbackSession);
		total.reportedAgents++;
		total.tokens += finiteMetric(metrics.tokens);
		total.requests += finiteMetric(metrics.requests);
		total.tools += finiteMetric(metrics.tools);
		total.cost += finiteMetric(metrics.cost);
		if (metrics.durationKind === "active") {
			total.durationMs += finiteMetric(metrics.durationMs);
			total.activeDurationAgents++;
		}
	}
	return { metrics: total, hasFallbackLiveSessions };
}

/** Parent-before-child projection preserving initial subtree rank and prepending new siblings. */
export function projectAgentTree<TRecord extends AgentRecordLike>(
	refs: readonly TRecord[],
	/** Rows spawned while the hub is open; such a child never lifts its parent's group. */
	spawnedWhileOpen?: (ref: TRecord) => boolean,
): AgentTreeProjection<TRecord> {
	const ids = new Set<string>();
	const operationalIndex = new Map<string, number>();
	for (let i = 0; i < refs.length; i++) {
		ids.add(refs[i].id);
		operationalIndex.set(refs[i].id, i);
	}

	const parentById = new Map<string, string>();
	const children = new Map<string, TRecord[]>();
	for (const ref of refs) {
		const parent =
			ref.parentId && ref.parentId !== MAIN_AGENT_ID && ids.has(ref.parentId) ? ref.parentId : MAIN_AGENT_ID;
		parentById.set(ref.id, parent);
		const siblings = children.get(parent);
		if (siblings) siblings.push(ref);
		else children.set(parent, [ref]);
	}

	// A tree group occupies the position of its earliest operational row.
	// Compute subtree minima iteratively so pathological lineage depth remains stack-safe.
	const subtreeOrder = new Map<string, number>();
	const visiting = new Set<string>();
	const ranked = new Set<string>();
	for (const start of refs) {
		if (ranked.has(start.id)) continue;
		const stack: Array<{ ref: TRecord; expanded: boolean }> = [{ ref: start, expanded: false }];
		while (stack.length > 0) {
			const current = stack.pop();
			if (!current) continue;
			if (current.expanded) {
				const own = operationalIndex.get(current.ref.id) ?? Number.MAX_SAFE_INTEGER;
				let order = own;
				for (const child of children.get(current.ref.id) ?? []) {
					// A child spawned later cannot move an existing parent's group.
					if (spawnedWhileOpen?.(child) && (operationalIndex.get(child.id) ?? Number.MAX_SAFE_INTEGER) < own) {
						continue;
					}
					order = Math.min(order, subtreeOrder.get(child.id) ?? Number.MAX_SAFE_INTEGER);
				}
				subtreeOrder.set(current.ref.id, order);
				visiting.delete(current.ref.id);
				ranked.add(current.ref.id);
				continue;
			}
			if (ranked.has(current.ref.id) || visiting.has(current.ref.id)) continue;
			visiting.add(current.ref.id);
			stack.push({ ref: current.ref, expanded: true });
			const descendants = children.get(current.ref.id);
			if (!descendants) continue;
			for (let i = descendants.length - 1; i >= 0; i--) {
				const child = descendants[i];
				if (!ranked.has(child.id) && !visiting.has(child.id)) stack.push({ ref: child, expanded: false });
			}
		}
	}
	for (const siblings of children.values()) {
		siblings.sort(
			(a, b) =>
				(subtreeOrder.get(a.id) ?? Number.MAX_SAFE_INTEGER) - (subtreeOrder.get(b.id) ?? Number.MAX_SAFE_INTEGER) ||
				(operationalIndex.get(a.id) ?? Number.MAX_SAFE_INTEGER) -
					(operationalIndex.get(b.id) ?? Number.MAX_SAFE_INTEGER),
		);
	}

	const lastSiblingById = new Map<string, boolean>();
	for (const siblings of children.values()) {
		for (let i = 0; i < siblings.length; i++) lastSiblingById.set(siblings[i].id, i === siblings.length - 1);
	}

	const rows: TRecord[] = [];
	const visited = new Set<string>();
	const depthById = new Map<string, number>();
	const visit = (root: TRecord, rootDepth: number): void => {
		const stack: Array<{ ref: TRecord; depth: number }> = [{ ref: root, depth: rootDepth }];
		while (stack.length > 0) {
			const current = stack.pop();
			if (!current || visited.has(current.ref.id)) continue;
			visited.add(current.ref.id);
			depthById.set(current.ref.id, current.depth);
			rows.push(current.ref);
			const descendants = children.get(current.ref.id);
			if (!descendants) continue;
			for (let i = descendants.length - 1; i >= 0; i--)
				stack.push({ ref: descendants[i], depth: current.depth + 1 });
		}
	};
	for (const root of children.get(MAIN_AGENT_ID) ?? []) visit(root, 0);
	// Corrupt persisted parent cycles remain visible as roots instead of disappearing.
	for (const ref of refs) visit(ref, 0);
	return { rows, depthById, parentById, lastSiblingById };
}
