import type { NativeToolHead, NativeToolView, ToolRenderer, ToolRenderResult } from "./renderer";
import { formatCount } from "@oh-my-pi/pi-utils";
import type { TspSpan } from "@oh-my-pi/pi-wire";
import { compact, md, node, row, span, text } from "../native/describe";
import type { NativeChild, NativeNode } from "../native/node";
import { OwnerMemo } from "../native/memo";
import { plainText } from "../native/spans";
import { noteText, resultText } from "./native-view";

import {
	type Component,
	lexDocument,
	Markdown,
	type MarkdownTheme,
	renderInlineMarkdown,
	replaceTabs,
	Text,
	truncateToWidth,
	visibleWidth,
} from "../index";

import type { RenderResultOptions } from "./renderer";

import { getMarkdownTheme, type Theme } from "../theme/theme";

import { outputBlockContentWidth, renderStatusLine } from "../render";
import { framedToolCard } from "../render/tool-card";
import { wrapPrefixedLine } from "../render/hanging-wrap";

import { formatErrorMessage, formatStatusIcon, formatTitle, sanitizeCarriageReturns } from "../render/render-utils";

/** Result for a single question */
export interface QuestionResult {
	id: string;
	question: string;
	options: string[];
	multi: boolean;
	selectedOptions: string[];
	customInput?: string;
	/** Optional note attached to the selected answer in the rich ask dialog. */
	note?: string;
	/** Label of the option the note is on; unset when it is on the custom answer. */
	noteOption?: string;
	/** True when the answer was auto-selected because the dialog timed out. */
	timedOut?: boolean;
}

/** Answers and redirect metadata displayed for an ask tool result. */
export interface AskToolDetails {
	question?: string;
	options?: string[];
	multi?: boolean;
	selectedOptions?: string[];
	customInput?: string;
	/** Optional note attached to the selected answer in the rich ask dialog. */
	note?: string;
	/** Label of the option the note is on; unset when it is on the custom answer. */
	noteOption?: string;
	/** True when the answer was auto-selected because the dialog timed out. */
	timedOut?: boolean;
	/** Multi-part question mode */
	results?: QuestionResult[];
	/** Chat redirect: the user chose "Chat about this" instead of answering. */
	chatRedirect?: boolean;
	/** Questions surfaced when chatRedirect is true. */
	questions?: string[];
}

// =============================================================================
// TUI Renderer
// =============================================================================

interface AskRenderOption {
	label: string;
	description?: string;
}

interface AskRenderArgs {
	question?: string;
	options?: AskRenderOption[];
	multi?: boolean;
	questions?: Array<{
		id: string;
		question: string;
		options: AskRenderOption[];
		multi?: boolean;
	}>;
}

/**
 * Coerce an untrusted option list (streamed or model-mangled call args) into
 * well-formed render options. Bare strings become labels; entries without a
 * string label are dropped.
 */
function normalizeRenderOptions(raw: unknown): AskRenderOption[] | undefined {
	if (!Array.isArray(raw)) return undefined;
	const out: AskRenderOption[] = [];
	for (const entry of raw) {
		if (typeof entry === "string") {
			out.push({ label: sanitizeCarriageReturns(entry) });
			continue;
		}
		if (!entry || typeof entry !== "object") continue;
		const { label, description } = entry as Partial<AskRenderOption>;
		if (typeof label !== "string") continue;
		out.push(
			typeof description === "string"
				? { label: sanitizeCarriageReturns(label), description: sanitizeCarriageReturns(description) }
				: { label: sanitizeCarriageReturns(label) },
		);
	}
	return out;
}

/**
 * Strip the `\r` runs degenerate models inject from persisted result details,
 * so transcripts completed before params sanitization still render as prose.
 * Display-only — the persisted payload is untouched.
 */
function sanitizeAskResultDetails(details: AskToolDetails): AskToolDetails {
	return {
		...details,
		...(details.question !== undefined ? { question: sanitizeCarriageReturns(details.question) } : {}),
		...(details.options !== undefined ? { options: details.options.map(sanitizeCarriageReturns) } : {}),
		...(details.selectedOptions !== undefined
			? { selectedOptions: details.selectedOptions.map(sanitizeCarriageReturns) }
			: {}),
		...(details.customInput !== undefined ? { customInput: sanitizeCarriageReturns(details.customInput) } : {}),
		...(details.note !== undefined ? { note: sanitizeCarriageReturns(details.note) } : {}),
		...(details.questions !== undefined ? { questions: details.questions.map(sanitizeCarriageReturns) } : {}),
		...(details.results !== undefined
			? {
					results: details.results.map(entry => ({
						...entry,
						id: sanitizeCarriageReturns(entry.id),
						question: sanitizeCarriageReturns(entry.question),
						options: entry.options.map(sanitizeCarriageReturns),
						selectedOptions: entry.selectedOptions.map(sanitizeCarriageReturns),
						...(entry.customInput !== undefined
							? { customInput: sanitizeCarriageReturns(entry.customInput) }
							: {}),
						...(entry.note !== undefined ? { note: sanitizeCarriageReturns(entry.note) } : {}),
					})),
				}
			: {}),
	};
}

/**
 * Coerce untrusted `questions` call args into a renderable array. Models
 * occasionally double-encode the array as a JSON string — a bare string passes
 * a truthy `.length` check but has no `.map`, which used to crash the TUI
 * render loop. Partially streamed args can also be missing fields.
 */
function normalizeRenderQuestions(raw: unknown): NonNullable<AskRenderArgs["questions"]> | undefined {
	if (typeof raw === "string") {
		try {
			raw = JSON.parse(raw);
		} catch {
			return undefined;
		}
	}
	if (!Array.isArray(raw)) return undefined;
	const out: NonNullable<AskRenderArgs["questions"]> = [];
	for (const entry of raw) {
		if (!entry || typeof entry !== "object") continue;
		const q = entry as Partial<NonNullable<AskRenderArgs["questions"]>[number]>;
		out.push({
			id: typeof q.id === "string" ? sanitizeCarriageReturns(q.id) : "?",
			question: typeof q.question === "string" ? sanitizeCarriageReturns(q.question) : "",
			options: normalizeRenderOptions(q.options) ?? [],
			multi: q.multi === true,
		});
	}
	return out;
}

/** Render a custom free-text answer as a status line plus indented continuation rows. */
function renderCustomInputLines(uiTheme: Theme, customInput: string): string[] {
	const lines = customInput.split("\n");
	const icon = formatStatusIcon("success", uiTheme);
	// Continuation rows line up under the answer text, past the glyph's own width.
	const indent = " ".repeat(visibleWidth(icon) + 2);
	const out: string[] = [` ${icon} ${uiTheme.fg("toolOutput", lines[0] ?? "")}`];
	for (let i = 1; i < lines.length; i++) out.push(`${indent}${uiTheme.fg("toolOutput", lines[i])}`);
	return out;
}

/** Render an answer note with tab replacement and line-width clamping. */
function renderNoteLines(uiTheme: Theme, note: string, width: number): string[] {
	const prefix = " Note: ";
	const continuationPrefix = "       ";
	const firstLineWidth = Math.max(1, width - visibleWidth(prefix));
	const continuationWidth = Math.max(1, width - visibleWidth(continuationPrefix));
	return replaceTabs(note)
		.split("\n")
		.map((line, index) => {
			const linePrefix = index === 0 ? `${uiTheme.fg("dim", " Note:")} ` : continuationPrefix;
			const maxWidth = index === 0 ? firstLineWidth : continuationWidth;
			return `${linePrefix}${uiTheme.fg("toolOutput", truncateToWidth(line, maxWidth))}`;
		});
}

/**
 * Marker glyph for a question option. Single-choice questions render circular radio
 * buttons (pick one); multi-select questions render rectangular checkboxes (pick many).
 */
export function optionMarker(uiTheme: Theme, multi: boolean | undefined, selected: boolean): string {
	if (multi) return selected ? uiTheme.checkbox.checked : uiTheme.checkbox.unchecked;
	return selected ? uiTheme.radio.selected : uiTheme.radio.unselected;
}

function wrapOptionLabel(marker: string, label: string, width: number): string[] {
	const prefix = ` ${marker} `;
	return wrapPrefixedLine(prefix, " ".repeat(visibleWidth(prefix)), label, width);
}

/** Render the offered options for a question form as flat marker bullets (no tree guides). */
function renderQuestionOptionLines(
	uiTheme: Theme,
	mdTheme: MarkdownTheme,
	options: AskRenderOption[],
	multi: boolean | undefined,
	width: number,
): string[] {
	const out: string[] = [];
	for (const opt of options) {
		const optLabel = renderInlineMarkdown(opt.label, mdTheme, t => uiTheme.fg("muted", t));
		out.push(...wrapOptionLabel(uiTheme.fg("dim", optionMarker(uiTheme, multi, false)), optLabel, width));
		if (opt.description?.trim()) {
			const description = renderInlineMarkdown(opt.description.trim(), mdTheme, t => uiTheme.fg("dim", t));
			const prefix = `   ${uiTheme.fg("dim", "↳")} `;
			out.push(...wrapPrefixedLine(prefix, " ".repeat(visibleWidth(prefix)), description, width));
		}
	}
	return out;
}

/** Flags of a question form: `multi` and its option count. */
function questionFlags(multi: boolean | undefined, optionCount: number): string[] {
	const flags: string[] = [];
	if (multi) flags.push("multi");
	if (optionCount > 0) flags.push(formatCount("option", optionCount));
	return flags;
}

/** Dim `multi · 3 options` footer flags, or undefined when there are none. */
function formatQuestionFlags(uiTheme: Theme, multi: boolean | undefined, optionCount: number): string | undefined {
	const flags = questionFlags(multi, optionCount);
	return flags.length > 0 ? uiTheme.fg("dim", flags.join(uiTheme.sep.dot)) : undefined;
}

/** A question's dim `(id · multi · 3 options)` tag in a multi-question card. */
interface QuestionTag {
	text: string;
	/** The question ends in a plain paragraph, so the tag may continue its last row. */
	afterText: boolean;
}

function questionTag(uiTheme: Theme, question: string, id: string, flags: readonly string[]): QuestionTag {
	const lastBlock = lexDocument(question).findLast(token => token.type !== "space");
	// Ids are model-supplied: a newline or tab would split or hole the row.
	const label = replaceTabs(id.replace(/\n+/g, " "));
	return {
		text: uiTheme.fg("dim", `(${[label, ...flags].join(uiTheme.sep.dot)})`),
		afterText: lastBlock?.type === "paragraph",
	};
}

/**
 * Append a `tag` after the last row of a rendered question, or give it a row of
 * its own when it does not fit there or would trail a list item, code fence or
 * table instead of the question's text.
 */
function appendQuestionTag(lines: readonly string[], tag: QuestionTag, contentWidth: number): string[] {
	// Markdown pads each row to the full width; the tag follows the text, not the padding.
	const last = lines.at(-1)?.trimEnd() ?? "";
	const fits = last.trim() !== "" && visibleWidth(last) + 1 + visibleWidth(tag.text) <= contentWidth;
	// A tag wider than the row wraps under its own one-column indent.
	if (!tag.afterText || !fits) return [...lines, ...wrapPrefixedLine(" ", " ", tag.text, contentWidth)];
	return [...lines.slice(0, -1), `${last} ${tag.text}`];
}

/** Header subject: the lone question's id on one row, or the question count. */
function askSubject(questions: readonly { id: string }[]): string {
	return questions.length === 1
		? replaceTabs(questions[0].id.replace(/\n+/g, " "))
		: formatCount("question", questions.length);
}

/**
 * Resolve selected labels to option indices against the RAW persisted labels.
 * Sanitizing can merge distinct options (`Retry\rnow`/`Retry now`) into one
 * display label, after which a label set would mark every colliding row —
 * indices survive normalization because it preserves order and length.
 * Every option exactly matching a selected label is marked: the legacy
 * selector recorded a single occurrence for duplicate rows it marked
 * together, while the rich dialog recorded one entry per row, and both
 * shapes must replay as originally shown.
 * Returns undefined when raw options are missing so the caller falls back to
 * label matching.
 */
function selectedIndicesFor(
	rawOptions: string[] | undefined,
	rawSelected: string[] | undefined,
): Set<number> | undefined {
	if (!rawOptions || rawOptions.length === 0) return undefined;
	const wanted = new Set(rawSelected ?? []);
	const indices = new Set<number>();
	rawOptions.forEach((option, index) => {
		if (wanted.has(option)) indices.add(index);
	});
	return indices;
}

/**
 * Render the answered option list for a question: every offered option with its
 * selection marker filled in, plus any custom free-text answer. Flat marker
 * bullets — the frame is the container, so no tree guides are drawn.
 */
function renderAnswerOptionLines(
	uiTheme: Theme,
	mdTheme: MarkdownTheme,
	options: string[] | undefined,
	selectedOptions: string[] | undefined,
	multi: boolean | undefined,
	customInput: string | undefined,
	note: string | undefined,
	width: number,
	contentWidth: number,
	selectedIndices?: ReadonlySet<number>,
): string[] {
	const selected = new Set(selectedOptions ?? []);
	// Prefer the full recorded option set; fall back to the selected labels when
	// details omit the options array.
	const list = options && options.length > 0 ? options : (selectedOptions ?? []);

	// Nothing was chosen (and no custom answer) → a lone cancelled marker.
	if (selected.size === 0 && customInput === undefined && note === undefined) {
		return [` ${formatStatusIcon("warning", uiTheme)} ${uiTheme.fg("warning", "Cancelled")}`];
	}

	const out: string[] = [];
	for (const [index, label] of list.entries()) {
		const isSelected = selectedIndices !== undefined ? selectedIndices.has(index) : selected.has(label);
		const marker = optionMarker(uiTheme, multi, isSelected);
		const markerStyled = isSelected ? uiTheme.fg("success", marker) : uiTheme.fg("dim", marker);
		const labelStyled = renderInlineMarkdown(label, mdTheme, t =>
			isSelected ? uiTheme.fg("toolOutput", t) : uiTheme.fg("muted", t),
		);
		out.push(...wrapOptionLabel(markerStyled, labelStyled, contentWidth));
	}
	if (customInput !== undefined) out.push(...renderCustomInputLines(uiTheme, customInput));
	if (note !== undefined) out.push(...renderNoteLines(uiTheme, note, width));
	return out;
}

function askHead(question: string | undefined, meta?: string): NativeToolHead {
	const first = question ? plainText(sanitizeCarriageReturns(question)).trim().split("\n")[0] : "";
	return { title: "Ask", target: first || undefined, targetKind: "text", meta: meta ? [meta] : undefined };
}

/** One question of a multi-question result: the question as markdown over its answers. */
function describeQuestionSection(id: string, question: string, rest: readonly NativeChild[]): NativeNode {
	return node("section", {}, [md(plainText(question)), ...rest], id);
}

/** An answer row: a success check before the chosen label, or a quiet unchosen label. */
function answerRow(key: string, label: TspSpan[], chosen: boolean): NativeNode {
	return row(
		compact([chosen ? node("icon", { name: "check", tone: "success" }) : undefined, text(label, { wrap: "word" })]),
		{ gap: "sm", align: "baseline", role: chosen ? "omp.tool.answer" : "omp.tool.answer.off", key },
	);
}

/**
 * Answered option list: every offered option marked chosen or not, plus any
 * quoted custom answer and a muted note. A lone "Cancelled" line when nothing was chosen.
 */
function describeAnswers(
	options: string[] | undefined,
	selectedOptions: string[] | undefined,
	customInput: string | undefined,
	note: string | undefined,
	selectedIndices: ReadonlySet<number> | undefined,
): NativeChild[] {
	const selected = new Set(selectedOptions ?? []);
	if (selected.size === 0 && customInput === undefined && note === undefined) {
		return [text([span("Cancelled", "warning")], { tone: "warning" })];
	}
	const labels = options && options.length > 0 ? options : (selectedOptions ?? []);
	const rows = labels.map((label, index) => {
		const isSelected = selectedIndices !== undefined ? selectedIndices.has(index) : selected.has(label);
		return answerRow(`${index}`, [span(plainText(label), isSelected ? "toolOutput" : "muted")], isSelected);
	});
	if (customInput !== undefined) {
		rows.push(answerRow("custom", [span(`\u201c${plainText(customInput)}\u201d`, "toolOutput")], true));
	}
	return compact([
		...rows,
		note !== undefined
			? text([span(plainText(note), "muted")], { wrap: "word", role: "omp.tool.context" })
			: undefined,
	]);
}

/** Pending ask: an inline head naming the question; the ask dialog owns the form. */
function describeAskCall(args: AskRenderArgs): NativeToolView {
	const questions = normalizeRenderQuestions(args.questions);
	const first = questions?.[0]?.question ?? (typeof args.question === "string" ? args.question : undefined);
	const more = questions && questions.length > 1 ? `${questions.length} questions` : undefined;
	return {
		tool: askHead(first, more),
		inline: true,
		body: [text([span("Waiting for your answer…", "muted")])],
	};
}

function describeAskResult(result: ToolRenderResult<AskToolDetails>, args: AskRenderArgs | undefined): NativeToolView {
	const rawDetails = result.details;
	const fallback = plainText(sanitizeCarriageReturns(resultText(result)));
	const argQuestion =
		normalizeRenderQuestions(args?.questions)?.[0]?.question ??
		(typeof args?.question === "string" ? args.question : undefined);
	if (!rawDetails) {
		return { tool: askHead(argQuestion), tone: "warning", body: fallback ? [noteText(fallback)] : undefined };
	}
	const details = sanitizeAskResultDetails(rawDetails);

	if (details.chatRedirect) {
		return {
			tool: askHead(details.questions?.[0] ?? argQuestion, "chat redirect"),
			tone: "info",
			body: (details.questions ?? []).map(q => md(plainText(q))),
		};
	}

	if (details.results && details.results.length > 0) {
		const results = details.results;
		const rawResults = rawDetails.results ?? [];
		const answered = results.some(
			r =>
				r.customInput !== undefined || r.note !== undefined || (r.selectedOptions && r.selectedOptions.length > 0),
		);
		return {
			tool: askHead(results[0]?.question, results.length > 1 ? `${results.length} questions` : undefined),
			tone: answered ? undefined : "warning",
			// Sanitizing preserves order and length, so raw indices align with `r`.
			body: results.map((r, index) =>
				describeQuestionSection(
					r.id,
					r.question,
					describeAnswers(
						r.options,
						r.selectedOptions,
						r.customInput,
						r.note,
						selectedIndicesFor(rawResults[index]?.options, rawResults[index]?.selectedOptions),
					),
				),
			),
		};
	}

	if (!details.question) {
		return { tool: askHead(argQuestion), body: fallback ? [text(fallback, { wrap: "word" })] : undefined };
	}

	const answered =
		details.customInput !== undefined ||
		details.note !== undefined ||
		(details.selectedOptions && details.selectedOptions.length > 0);
	return {
		tool: askHead(details.question),
		tone: answered ? undefined : "warning",
		body: compact([
			md(plainText(details.question)),
			...describeAnswers(
				details.options,
				details.selectedOptions,
				details.customInput,
				details.note,
				selectedIndicesFor(rawDetails.options, rawDetails.selectedOptions),
			),
			details.timedOut
				? text([span("auto-selected after timeout — not a user choice", "muted")], {
						wrap: "word",
						role: "omp.tool.notice",
					})
				: undefined,
		]),
	};
}

const askCallMemo = new OwnerMemo<NativeToolView | undefined>();
const askResultMemo = new OwnerMemo<NativeToolView | undefined>();

/** Render question forms and their recorded answers. */
export const askToolRenderer = {
	describeCall(args: AskRenderArgs): NativeToolView | undefined {
		return askCallMemo.get(args, [JSON.stringify(args)], () => describeAskCall(args));
	},
	describeResult(
		result: ToolRenderResult<AskToolDetails>,
		_options?: RenderResultOptions,
		args?: AskRenderArgs,
	): NativeToolView | undefined {
		return askResultMemo.get(result, [], () => describeAskResult(result, args));
	},
	mergeCallAndResult: true,
	renderCall(args: AskRenderArgs, _options: RenderResultOptions, uiTheme: Theme): Component {
		const label = formatTitle("Ask", uiTheme);
		const mdTheme = getMarkdownTheme();
		const accentStyle = { color: (t: string) => uiTheme.fg("accent", t) };
		const md = (text: string, width: number) =>
			new Markdown(text, 1, 0, mdTheme, accentStyle).render(Math.max(1, outputBlockContentWidth(width) + 1));

		// Call args are untrusted (partially streamed or model-mangled) and a
		// throw here takes down the whole TUI render loop — normalize first.
		const questions = normalizeRenderQuestions(args.questions);
		if (questions && questions.length > 0) {
			const header = `${label}: ${uiTheme.fg("muted", askSubject(questions))}`;
			// One question: its id is the header subject and its flags the footer.
			// Several: each question is tagged with its id and flags, divided by plain separators.
			const lone = questions.length === 1 ? questions[0] : undefined;
			const footerMeta = lone ? formatQuestionFlags(uiTheme, lone.multi, lone.options.length) : undefined;
			const tags = lone
				? undefined
				: questions.map(q => questionTag(uiTheme, q.question, q.id, questionFlags(q.multi, q.options.length)));
			return framedToolCard(uiTheme, ({ width, contentWidth }) => {
				const sections = questions.map((q, index) => {
					const mdLines = md(q.question, width);
					// md() returns a shared cached array (module-level Markdown LRU) — copy before appending.
					const content = [
						...(tags ? appendQuestionTag(mdLines, tags[index]!, contentWidth) : mdLines),
						...renderQuestionOptionLines(uiTheme, mdTheme, q.options, q.multi, contentWidth),
					];
					return { content, separator: index > 0 };
				});
				return { header, sections, footerMeta, phase: "pending", borderColor: "borderMuted" };
			});
		}

		// Single question
		if (typeof args.question !== "string" || !args.question) {
			const errorLine = formatErrorMessage("No question provided", uiTheme);
			return framedToolCard(uiTheme, () => ({
				header: errorLine,
				sections: [],
				phase: "error",
				borderColor: "error",
			}));
		}

		const question = sanitizeCarriageReturns(args.question);
		const questionOptions = normalizeRenderOptions(args.options) ?? [];
		const multi = args.multi;
		const footerMeta = formatQuestionFlags(uiTheme, multi, questionOptions.length);
		return framedToolCard(uiTheme, ({ width, contentWidth }) => {
			// md() returns a shared cached array (module-level Markdown LRU) — copy before appending.
			const bodyLines = [
				...md(question, width),
				...renderQuestionOptionLines(uiTheme, mdTheme, questionOptions, multi, contentWidth),
			];
			return {
				header: label,
				sections: bodyLines.length > 0 ? [{ content: bodyLines }] : [],
				footerMeta,
				phase: "pending",
				borderColor: "borderMuted",
			};
		});
	},

	renderResult(
		result: { content: Array<{ type: string; text?: string }>; details?: AskToolDetails },
		_options: RenderResultOptions,
		uiTheme: Theme,
		args?: AskRenderArgs,
	): Component {
		const rawDetails = result.details;
		const mdTheme = getMarkdownTheme();
		const accentStyle = { color: (t: string) => uiTheme.fg("accent", t) };
		const md = (text: string, width: number) =>
			new Markdown(text, 1, 0, mdTheme, accentStyle).render(Math.max(1, outputBlockContentWidth(width) + 1));

		const argQuestions = normalizeRenderQuestions(args?.questions);
		const argSubject = argQuestions?.length ? askSubject(argQuestions) : undefined;

		if (!rawDetails) {
			const txt = result.content[0];
			const fallback = txt?.type === "text" && txt.text ? sanitizeCarriageReturns(txt.text) : "";
			const header = renderStatusLine({ icon: "warning", title: "Ask", description: argSubject }, uiTheme);
			const body = fallback ? `\n${uiTheme.fg("dim", fallback)}` : "";
			return new Text(`${header}${body}`, 0, 0);
		}
		const details = sanitizeAskResultDetails(rawDetails);

		// Chat redirect: user chose "Chat about this" instead of answering.
		if (details.chatRedirect) {
			const header = renderStatusLine(
				{ icon: "info", title: "Ask", description: argSubject, meta: ["chat redirect"] },
				uiTheme,
			);
			const questions = details.questions ?? [];
			return framedToolCard(uiTheme, ({ width }) => ({
				header,
				sections: questions.length > 0 ? [{ content: questions.flatMap(q => md(q, width)) }] : [],
				phase: "warning",
				borderColor: "borderMuted",
			}));
		}

		// Multi-part results: one separator-divided section per question, each tagged with its id.
		if (details.results && details.results.length > 0) {
			const results = details.results;
			const hasAnySelection = results.some(
				r =>
					r.customInput !== undefined ||
					r.note !== undefined ||
					(r.selectedOptions && r.selectedOptions.length > 0),
			);
			const tags =
				results.length === 1
					? undefined
					: results.map(r => questionTag(uiTheme, r.question, r.id, r.multi ? ["multi"] : []));
			const header = renderStatusLine(
				{
					icon: hasAnySelection ? "success" : "warning",
					title: "Ask",
					description: askSubject(results),
				},
				uiTheme,
			);
			return framedToolCard(uiTheme, ({ width, contentWidth }) => {
				const rawResults = rawDetails.results ?? [];
				const sections = results.map((r, index) => {
					// Sanitizing preserves order and length, so raw indices align with `r`.
					const raw = rawResults[index];
					const mdLines = md(r.question, width);
					// md() returns a shared cached array (module-level Markdown LRU) — copy before appending.
					const lines = [
						...(tags ? appendQuestionTag(mdLines, tags[index]!, contentWidth) : mdLines),
						...renderAnswerOptionLines(
							uiTheme,
							mdTheme,
							r.options,
							r.selectedOptions,
							r.multi,
							r.customInput,
							r.note,
							width,
							contentWidth,
							selectedIndicesFor(raw?.options, raw?.selectedOptions),
						),
					];
					return { content: lines, separator: index > 0 };
				});
				return {
					header,
					sections,
					phase: hasAnySelection ? "success" : "warning",
					borderColor: "borderMuted",
				};
			});
		}

		// Single question result
		if (!details.question) {
			const txt = result.content[0];
			const fallback = txt?.type === "text" && txt.text ? sanitizeCarriageReturns(txt.text) : "";
			return new Text(fallback, 0, 0);
		}

		const question = details.question;
		const hasSelection =
			details.customInput !== undefined ||
			details.note !== undefined ||
			(details.selectedOptions && details.selectedOptions.length > 0);
		const header = renderStatusLine(
			hasSelection
				? { iconOverride: uiTheme.styledSymbol("tool.ask", "accent"), title: "Ask", description: argSubject }
				: { icon: "warning", title: "Ask", description: argSubject },
			uiTheme,
		);
		const dOptions = details.options;
		const dSelected = details.selectedOptions;
		const dMulti = details.multi;
		const dCustom = details.customInput;
		const dNote = details.note;
		const dTimedOut = details.timedOut;
		return framedToolCard(uiTheme, ({ width, contentWidth }) => {
			// md() returns a shared cached array (module-level Markdown LRU) — copy before appending.
			const bodyLines = [
				...md(question, width),
				...renderAnswerOptionLines(
					uiTheme,
					mdTheme,
					dOptions,
					dSelected,
					dMulti,
					dCustom,
					dNote,
					width,
					contentWidth,
					selectedIndicesFor(rawDetails.options, rawDetails.selectedOptions),
				),
			];
			if (dTimedOut) {
				// Distinguish auto-selection from a real user choice in the transcript.
				bodyLines.push(uiTheme.fg("dim", "auto-selected after timeout — not a user choice"));
			}
			return {
				header,
				sections: bodyLines.length > 0 ? [{ content: bodyLines }] : [],
				phase: hasSelection ? "success" : "warning",
				borderColor: "borderMuted",
			};
		});
	},
} satisfies ToolRenderer<AskRenderArgs, AskToolDetails>;
